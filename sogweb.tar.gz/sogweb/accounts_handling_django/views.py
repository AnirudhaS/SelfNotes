"""
Module contains views of accounts application
"""
import logging
from django.conf import settings
from django.shortcuts import render
from django.http import HttpResponseRedirect, JsonResponse
from django.core.urlresolvers import reverse
from django.views.decorators.csrf import csrf_exempt
from django.contrib import messages
from django.views.generic import View
from django.utils.decorators import method_decorator
import requests
import json
from django.http import JsonResponse
from library.decorators import anonymous_only
from accounts_handling_django.view_helper import User


class Welcome(View):
    """
    View to handle home page.
    """

    def get(self, request):
        """
        This method renders the welcome page.
        """
        return render(request, 'accounts/welcome.html')


class SignUpView(View):
    """
    Class based view to handle signup form
    """

    @method_decorator(anonymous_only)
    def dispatch(self, *args, **kwargs):
        return super(SignUpView, self).dispatch(*args, **kwargs)

    def get(self, request):
        """
        This method will render signup page.
        """

        return render(request, "accounts/signup.html")

    def post(self, request):
        """
        It will call the save method to register the user on success it will
        redirect to activation page and in case of error it will render
        signup page with errors on it.
        """
        post_data = request.POST.dict()
        response_data = User.save(post_data)
        return JsonResponse(response_data)


class SignInView(View):
    """
    View to handle signin request
    """

    @method_decorator(anonymous_only)
    @method_decorator(csrf_exempt)
    def dispatch(self, *args, **kwargs):
        return super(SignInView, self).dispatch(*args, **kwargs)

    def get(self, request):
        """
        Renders just the signin page.
        """

        return render(request, 'accounts/signin.html')

    def post(self, request):
        """
        Calls the authenticate method to login the user on successJsonResponse(json.dumps(vm_list), safe=False) it will
        redirect to vms/cc page and in case of error
        it will render signin page with errors on it.
        """

        username = request.POST.get('username')
        password = request.POST.get('password')
        resp = User.authenticate(username, password)
        if resp['status'] != 'error':
            auth_token = resp.get('auth_token')
            credit_card_present = True
            user_info = User.get_user_info(auth_token)
            User.login(request, auth_token, user_info, credit_card_present)
            messages.success(request, 'You are successfully signed in')
        return JsonResponse(resp)

class SignOutView(View):
    """"
    View to handle sign out request
    """

    def get(self, request):
        """
        This will call the logout helper method and redirects to signin page.
        """

        messages.success(request, 'You are successfully signed out')
        User.logout(request)
        return HttpResponseRedirect(reverse('accounts:signin'))

class RenderActivateAccountTemplate(View):
    
    def get(self, request):
	activation_token = request.GET.get('activation_token')
	return render(request, 'accounts/activation_token.html', {'activation_token': activation_token})

class ActivateAccountView(View):
    """
    Handles request to activate user account.
    """

    def get(self, request, activation_token):
        """
        This method activates the user's account and redirects it to the
        signin page.
        """

        data = {'activation_token': activation_token}
        User.activate_account(data)
        return HttpResponseRedirect(reverse('accounts:signin'))

class SaveCCDetailsView(View):
    """
    Handles request to save gredit card details of user.
    """

    @method_decorator(csrf_exempt)
    def dispatch(self, *args, **kwargs):
        return super(SaveCCDetailsView, self).dispatch(*args, **kwargs)

    def post(self, request):
        """
        It will call the save_cc_details method which will save the
        credit card details for the current user.
        """

        cc_number = request.POST.get('credit_card_number')
        data = {'cc_number': cc_number,
                'auth_token': request.session['auth_token']}
        response = User.save_cc_details(data)
        if response['status'] == 'success':
            request.session['credit_card_present'] = True
            messages.success(request, response['message'])
        else:
            messages.error(request, response['message'])

        return HttpResponseRedirect(reverse('vms:vm_index'))


class BillsView(View):
    @method_decorator(csrf_exempt)
    def dispatch(self, *args, **kwargs):
        return super(BillsView, self).dispatch(*args, **kwargs)

    def get(self, request, id):
        auth_token = request.session['auth_token']
        headers = {
            'Authorization': "Token %s" % (auth_token)
        }
        bill = '{}accounts/bills/{}'.format(settings.APP_SERVER_BASE_URL, id)
        payload = {'auth_token': auth_token}
        resp = requests.get(bill, data=payload, headers=headers)
        return render(request, "accounts/bill.html", {"bill": resp.json()})


class BillingHistoryView(View):

    @method_decorator(csrf_exempt)
    def dispatch(self, *args, **kwargs):
        return super(BillingHistoryView, self).dispatch(*args, **kwargs)

    def get(self, request):
        auth_token = request.session['auth_token']

        billing_history = '{}accounts/billing_history/'.format(settings.APP_SERVER_BASE_URL)
        print billing_history
        payload = {'auth_token': auth_token}
        headers = {
            'Authorization': "Token %s" % (auth_token)
        }
        resp = requests.get(billing_history, data=payload, headers=headers)
        response = resp.json()
	print resp.json()
        print len(response)
        print type(response[0])
        bills = response
        return render(request, "accounts/billing.html", {"bills": bills})
