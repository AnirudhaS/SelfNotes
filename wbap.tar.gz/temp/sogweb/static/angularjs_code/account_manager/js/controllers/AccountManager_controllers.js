AccountManager_app.controller('AccountManager_controller',function($scope){
	$scope.ChangePersonal= true;
	$scope.UserFirstName = "qweqw";
	$scope.UserMiddleName = "qwd";
	$scope.UserLastName = "fwef";
	$scope.UserEmail = "efw@fwef.com";
	$scope.PhoneCountryCode = "+1";
	$scope.PhoneNumber = "1234567891";
	$scope.Address1 = "fewfwefwefwe";
	$scope.Address2 = "efwefeweww";
	$scope.State = "NJ";
	$scope.Country = "US";
	$scope.Zipcode = "07030";
	$scope.EnableEdit = function(){
		$scope.ChangePersonal = false;
	}
	$scope.DisableEdit = function(){
		$scope.ChangePersonal = true;
	}

	$scope.ChangePassword = true;
	$scope.OriginalPW = "";
	$scope.NewPassword = "";
	$scope.NewPasswordAgain = "";
	$scope.EnableChangePW = function(){
		$scope.ChangePassword = false;
		$scope.OriginalPW = "";
	}
	$scope.DisableChangePW = function(){
		$scope.NewPassword = "";
		$scope.NewPasswordAgain = "";
		$scope.ChangePassword = true;
	}

	$scope.CreditType = "";
	$scope.LastFourDigit1 = "0000";
	$scope.LastFourDigit2 = "0000";
	$scope.LastFourDigit3 = "0000";
	$scope.LastFourDigit4 = "0000";
	$scope.LastFourDigit5 = "0000";
	$scope.Four1 = "";
	$scope.Four2 = "";
	$scope.Four3 = "";
	$scope.Four4 = "";
	$scope.expirationday = "";
	$scope.expirationmonth= "";
	$scope.CreditAddress1 = "fewfwefwefwe";
	$scope.CreditAddress2 = "efwefeweww";
	$scope.CreditState = "NJ";
	$scope.CreditCountry = "US";
	$scope.CreditZipcode = "07030";
	$scope.AddCreditCard = false;
	$scope.CreditCard1 = "00000000000000";
	$scope.CreditCard2 = "11111111111111";
	$scope.CreditCard3 = "22222222222222";
	$scope.CreditCard4 = "33333333333333";
	$scope.CreditCard5 = "44444444444444";
	$scope.Expirationdate1 = "01/01";
	$scope.Expirationdate2 = "02/02";
	$Scope.Expirationdate3 = "03/03";
	$scope.Expirationdate4 = "04/04";
	$Scope.Expirationdate5 = "05/05";
});