signup_app.controller('signUpCtrl', ['$scope', '$http', '$parse', '$sce', function($scope, $http, $parse, $sce) {

  $scope.errorMessages = '';

  $scope.signUp = function(){

    var xsrf = $("form").serialize();
    $http({
      method: 'post',
      url: '/accounts/signup',
      data: xsrf,
      headers: {'Content-Type': 'application/x-www-form-urlencoded'}
    }).then(function successCallback(response) {
      if(response.data['status'] == 'success'){
        window.location.assign('/accounts/signin');
      }
      else{
	angular.forEach(response.data['errors'], function(value, key){
	  var model = $parse('error_'+key);
	  model.assign($scope, value);
	});
      }
      }, function errorCallback(response) {
    });
  }

}]).config(function($interpolateProvider) {
  $interpolateProvider.startSymbol('[[');
  $interpolateProvider.endSymbol(']]');
});
