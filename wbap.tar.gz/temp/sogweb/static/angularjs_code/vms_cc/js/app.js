var listVMS = angular.module('VMListApp', []);

var createVM = angular.module('createVMApp', []);
