listVMS.controller('vmInfoController', ['$scope', '$http', function($scope, $http) {
  
  //initialize page on first visit or refresh
  if($scope.vms === undefined){
    $scope.vms = [];
    $scope.empty = null;
    getVMS(); 
  }
  
  function getVMS(){
    $http({
    method: 'get',
    url: '/cc/get_vms/'
    }).then(function successCallback(response) {
	  resp = JSON.parse(response.data)
          if(resp.length){
            $scope.vms = resp; //response.data or response['data'] ?
            $scope.empty = false;
          }
          else{
            $scope.empty = true;
          }
    }, function errorCallback(response) {
          //some error here ?
    });
  }

  $scope.removeVM = function(virtualM) {
    sosUrl = '/cc/sos_vms/?vms_name='+scope.info.name+'&new_status=delete'
    $http({
            method: 'get',
            url: sosUrl
        }).then(function successCallback(response) {
            resp = response.data
      if (resp['status'] == 'success'){
              var index = $scope.vms.indexOf(virtualM);    
              $scope.vms.splice(index, 1);
      }
      else{
        alert(resp['message']);
      }
      }, function errorCallback(response) {
            //some error here ?
      });

  };
  $scope.name="edevadmin:systemongrid";
  $scope.accessVM = function(){
    vncurl = '/cc/access_vms'
    $http({
      method: 'get', 
      url: vncurl, 
    }).then(function successCallback(response) {
      if(response['status'] == '200'){
        window.location.assign('/cc/access/?token='+$scope.name);
      }
      else{
        //$scope.errorMessages = response['data']['non_field_errors']
        alert(response['status']);
      }
    });
  };

}]);
