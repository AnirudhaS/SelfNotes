createVM.controller('createVMController', ['$scope', '$http', function($scope, $http) {
  $scope.servers = [{name:"Centos", src:"centos.png", osname: "ceph-centos"}]; 
  $scope.workStations = [{name:"Ubuntu", src:"ubuntu.png", osname:"uknown"}];
  $scope.showservers = true;
  $scope.showworkStations = true;	
  $scope.virtual_machine = {
	name: "", 
	image: "", 
	flavor: "", 
	vm_description: "", 
	availability_zone: "", 
	};

  $scope.showServers = function(){
	$scope.showservers = false;
	$scope.showworkStations = true;
};

$scope.hideWS = function(){
$scope.showservers = true;
        $scope.showworkStations = false;

};

$scope.createVM = function(){
    var xsrf = $("form").serialize();
$http({
      method: 'post',
      url: '/cc/new',
      data: xsrf,
      headers: {'Content-Type': 'application/x-www-form-urlencoded'}
    }).then(function successCallback(response) {
      if(response.data['status'] == 'success'){
        window.location.assign('/cc');
      }
      else{
        angular.forEach(response.data['errors'], function(value, key){
          var model = $parse('error_'+key);
          model.assign($scope, value);
        });
      }
      }, function errorCallback(response) {
    });
  }



}]).config(function($interpolateProvider) {
  $interpolateProvider.startSymbol('[[');
  $interpolateProvider.endSymbol(']]');
});

