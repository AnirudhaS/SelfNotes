$(document).ready(function(){
	$("#WorkStationID").hide();
	$("#ServerID").hide();
	$("#WorkStationButton").click(function(){
		$("#WorkStationID").show();
		$("#ServerID").hide();
	});
	$("#ServerButton").click(function(){
		$("#WorkStationID").hide();
		$("#ServerID").show();
	});
});

