"""
Module contains views related to vms application
"""

import json

from django.shortcuts import render, redirect
from django.views.generic import View
from django.utils.decorators import method_decorator
from django.http import JsonResponse, HttpResponseRedirect

from library.decorators import valid_token_only, credit_card_required
from vms_handling_django.view_helper import VirtualMachine

class Index(View):
    """
    View to show virtual machines
    """

    @method_decorator(valid_token_only)
    def dispatch(self, *args, **kwargs):
        return super(Index, self).dispatch(*args, **kwargs)

    def get(self, request):
        """
        Renders list of virtual machines related to user
        """
        return render(request, 'vms/index.html')


class CreateVirtualMachine(View):
    """
    View to create new virtual machine.
    """

    @method_decorator(credit_card_required)
    def dispatch(self, *args, **kwargs):
        return super(CreateVirtualMachine, self).dispatch(*args, **kwargs)

    def get(self, request):
        """
        Renders form to create new virtual machine.

        """
        #auth_token = request.session['auth_token']
        #img_list = VirtualMachine.get_images(auth_token)
        #flv_list = VirtualMachine.get_flavors(auth_token)
        #return JsonResponse(json.dumps([flv_list,img_list]), safe=False)

        return render(request, 'vms/new.html')
    def post(self, request):
        """
        Creates new virtual machine
        """
	post_data = request.POST.dict()
	print post_data
	response_data = VirtualMachine.create_vm(post_data)
	return JsonResponse(response_data)

class GetVms(View):
    """
    View to get list of vm instances
    """

    @method_decorator(valid_token_only)
    def dispatch(self, *args, **kwargs):
        return super(GetVms, self).dispatch(*args, **kwargs)

    def get(self, request):
        """
        Renders list of virtual machines related to user
        """

        auth_token = request.session['auth_token']
        vm_list = VirtualMachine.get_user_vms(auth_token)
        return JsonResponse(json.dumps(vm_list), safe=False)

class ChangeVmsStatus(View):
    """ 
    Make put request for Pause, Unpause, Delete
    """

    @method_decorator(valid_token_only)
    def dispatch(self, *args, **kwargs):
        return super(ChangeVmsStatus, self).dispatch(*args, **kwargs)
    
    def get(self, request):
        """
        Pause, Unpause, Delete VM
        """

	vms_name = request.GET.get('vms_name')
        auth_token = request.session['auth_token']
        new_status = request.GET.get('new_status')

	if new_status == 'play':
            response = VirtualMachine.start_vms(auth_token, vms_name)
	elif new_status == 'pause':
            response = VirtualMachine.pause_vms(auth_token, vms_name)
        elif new_status == 'delete':
            response = VirtualMachine.delete_vms(auth_token, vms_name)
	else:
            response = {"status": "error", "message": "Provided status is not valid."}
	print "********************************", response
        return JsonResponse(response)
        
class AccessVms(View):
    """ 
    acess noVNC html5 GUI console to VM
    """
    @method_decorator(valid_token_only)
    def dispatch(self, *args, **kwargs):
        return super(AccessVms, self).dispatch(*args, **kwargs)
    
    def get(self, request):
        """
        Renders list of virtual machines related to user
        """
    	#vms_name = request.GET.get('vms_name')
    	auth_token = request.session['auth_token']
        print auth_token
    	response = VirtualMachine.access_vm(auth_token)
        print type(response)
        if response['status'] == 'success':
            return JsonResponse(response)
        else:
            response = {'status': "Cannot access VM"}
            return JsonResponse(response)
    	#print "********************************", response
    	
class Vnc(View):
    """ 
    acess noVNC html5 GUI console to VM
    """
    @method_decorator(valid_token_only)
    def dispatch(self, *args, **kwargs):
        return super(Vnc, self).dispatch(*args, **kwargs)
    
    def get(self, request):
        """
        Renders list of virtual machines related to user
        """
        vms_name = request.GET.get('vms_name')
        return render(request, 'vms/vnc_auto.html/')


