from django.conf.urls import include, url
from views import virtual_machines

urlpatterns = [
  url(r'^$',
      virtual_machines.Index.as_view(),
      name='vm_index'),

  url(r'^get_vms/$',
      virtual_machines.GetVms.as_view(),
      name='get_vms'),

   url(r'^sos_vms/$',
      virtual_machines.ChangeVmsStatus.as_view(),
      name='sos_vms'),

  url(r'^new$',
      virtual_machines.CreateVirtualMachine.as_view(),
      name='vm_new'),
  url(r'^access_vms/$',
      virtual_machines.AccessVms.as_view(),
      name='access_vms'),
  url(r'^access/', 
	virtual_machines.Vnc.as_view(), 
	name='access'),
  
]
