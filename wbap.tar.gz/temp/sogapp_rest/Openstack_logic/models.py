from django.db import models
from djoser.models import User
from django.conf import settings
from django.utils import timezone
# from .managers import CustomerManager

class VNCConnection(models.Model):
    token = models.CharField(primary_key=True,max_length=50)
    port = models.CharField(max_length=10)
    ip = models.CharField(max_length=20)


class StripeObject(models.Model):

    stripe_id = models.CharField(max_length=255, unique=True)
    created_at = models.DateTimeField(default=timezone.now)

    class Meta:
        abstract = True


class VMDetails(models.Model):
    vm_flavor = models.CharField(null=False, max_length=250)
    daily = models.FloatField(null=False)
    monthly = models.FloatField(null=False)
    C12 = models.FloatField(null=False)
    C24 = models.FloatField(null=False)
    created_at = models.DateTimeField(default=timezone.now)
    updated_at = models.DateTimeField(auto_now=True)


class Createvm(models.Model):

    # VM status
    STOPPED = 0
    RUNNING = 1
    PAUSED = 2
    DELETED = 3
    STATUS = (
        (DELETED, 'Deleted'),
        (RUNNING, 'Running'),
        (PAUSED, 'Paused'),
    )

    # VM's physical location
    NEW_JERSEY = 0
    CALIFORNIA = 1
    LOCATION = (
        (NEW_JERSEY, 'NEW_JERSEY'),
        (CALIFORNIA, 'CALIFORNIA')
    )

    DAILY = 0
    MONTHLY = 1
    COMMITMENT = 2
    BILLING_TYPE = (
        (DAILY, 'Daily'),
        (MONTHLY, 'Monthly'),
        (COMMITMENT, 'Commitment')
    )

    user = models.ForeignKey(settings.AUTH_USER_MODEL, related_name='virtual_machines')
    vm_name = models.CharField(max_length=50)
    image = models.CharField(max_length=50)
    #vm_flavor = models.ForeignKey(VMDetails)
    #flavor = models.CharField(max_length=100)
    ram = models.CharField(max_length=50)
    vcpus = models.CharField(max_length=50)
    disk = models.CharField(max_length=50)
    description = models.CharField(max_length=100)
    availability_zone = models.CharField(max_length=100)
    openstack_id = models.CharField(null=False, max_length=200)
    #location = models.IntegerField(choices=LOCATION)
    #billing_type = models.IntegerField(choices=BILLING_TYPE)
    billing_expiry = models.DateTimeField(blank=True, null=True, default=None)
    last_payment = models.DateTimeField(blank=True, null=True, default=None)
    running_days = models.PositiveIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.vm_name
