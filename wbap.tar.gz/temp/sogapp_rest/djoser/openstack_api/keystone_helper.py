from keystoneclient.v2_0 import client


def create_Keystone_user(username, password, email):
    print("Calling create keystone user methond")
    token = 'f0a4af517fc95b8837a1'
    endpoint = 'http://vsusnjhhdiosconvip:35357/v2.0'
    keystone = client.Client(token=token, endpoint=endpoint)

    # create new project for user
    # unique_tenant_id=""
    new_tenant = keystone.tenants.create(tenant_name=username, description="System on grid user project.", enabled=True)
    # create corresponding openstack user
    new_user = keystone.users.create(name=username, password=password, email=email, tenant_id=new_tenant.id)

    # add role to user
    roles = keystone.roles.list()
    for y in roles:
        if y.name == 'user':
            role = y
    st = keystone.roles.add_user_role(new_user, role, new_tenant)
    print(st)


def update_keystone_user_password(username, new_password):
    try:
        keystone = get_keystone_instance()
        user = get_keystone_user_by_name(keystone, username)
        keystone.users.update_password(user, new_password)
    except ValueError as e:
        # log error
        pass


def get_keystone_instance():

    token = get_token()
    endpoint = 'http://vsusnjhhdiosconvip:35357/v2.0'  # settings.KEYSTONE_ENDPOINT
    return client.Client(token=token, endpoint=endpoint)


def get_token():
    token = 'f0a4af517fc95b8837a1'
    return token


def get_keystone_user_by_name(keystone, username):

    keystone_user = None

    for user in keystone.users.list():
        if user.username == username:
            keystone_user = user

    if keystone_user:
        return keystone_user
    #    else:
    # raise ValueError('User with %s does not exist in keystone.', %(username))
