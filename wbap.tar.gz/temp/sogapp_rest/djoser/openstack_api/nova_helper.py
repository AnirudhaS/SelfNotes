from novaclient import client
from novaclient.exceptions import NotFound as FlavorNotFound
from cinderclient import client as cclient
from .cinder_helper import cinderAuth, cinderMain
import time
import libvirt
import xml.etree.ElementTree as ET
import MySQLdb


username = "adminliberty"
version = '2'
passwd = "558d571e9dec51a50689"
auth_url = "http://vsusnjhhdiosconvip:5000/v2.0"
tenant_name = "adminliberty"
cinder = cclient.Client(version, username, passwd, tenant_name, auth_url)

# nova = client.Client(version=2, username="adminliberty", password="558d571e9dec51a50689", project_id="admin", auth_url="http://vsusnjhhdiosconvip:5000/v2.0", connection_pool=True)


# Createing Method for login the current user in Nova API
def login_nova_client(username, password):
    # TODO: create a function for getting the auth_url
    version = 2  # settings.NOVA_VERSION
    auth_url = 'http://vsusnjhhdiosconvip:5000/v2.0'  # settings.AUTH_URL

    nova = client.Client(version, username, password, username, auth_url, connection_pool=True)
    return nova


# Get the vm for Requested User
def get_vm_instances_of_user(username, password):
    nova = login_nova_client(username, password)
    vm_servers = nova.servers.list()
    flavors = nova.flavors.list()
    vm_servers_dict = []
    for vm_server in vm_servers:
        vm_servers_dict.append(get_vm_server_details(vm_server, username, flavors))
    return vm_servers_dict


# Geting the vm detatils
def get_vm_server_details(vm_server, username, flavors=[]):
    attr = {}
    attr['status'] = vm_server.status
    attr['name'] = vm_server.name
    attr['vm_id'] = vm_server.id
    flavor = vm_server.flavor['id']
    for f in flavors:
        if f.id == flavor:
            attr['vcpus'] = f.vcpus
            attr['ram'] = f.ram
            attr['disk'] = f.disk
    return attr


# Geting Vm based on name of the Vm
def get_vm_server_by_id(vm_server_id, username, password):
    nova = login_nova_client(username, password)
    print('*********',vm_server_id)
    #vm_servers = nova.servers.list(search_opts={'name': vm_server_name})
    vm_servers = nova.servers.list()
    for vm in vm_servers:
        if vm.id == vm_server_id:
            print ('get_vm_server_by_id function:',vm.id)
            return vm
    return False


# Pauseing the vm
def pause_vm_server(vm_server, username, password):
    nova = login_nova_client(username, password)
    if vm_server.status != "PAUSED":
        nova.servers.shelve(vm_server)
        return True
    else:
        return False
        print("Throw exception")


# UnPauseing the Vm
def unpause_vm_server(vm_server, username, password):
    nova = login_nova_client(username, password)
    if vm_server.status == "SHELVED_OFFLOADED":
        nova.servers.unshelve(vm_server)
        return True
    else:
        return False
        print("Throw exception")


# Deleteing the VM
def delete_vm_server(vm_server, username, password):
    nova = login_nova_client(username, password)
    print('deleting vm:', vm_server.id)
    nova.servers.delete(vm_server)

    # TODO if want to check if the vm is deleted, this method need to be changed!
    for server in nova.servers.list():
        if server.id == vm_server.id:
            return False

    return True


def rename_vm_server(vm_server, new_name, username, password):
    nova = login_nova_client(username, password)
    nova.servers.update(vm_server, new_name)


# Geting all the available Images
def get_all_images(username, password):
    nova = login_nova_client(username, password)
    images = [(x.name, x.id) for x in nova.images.list()]
    # result = (images)
    return images


# Getting the all the available
def get_all_flavors(username, password):
    nova = login_nova_client(username, password)
    #flavors = nova.flavors.list()
    flavors = [(x.name, x.id) for x in nova.flavors.list()]
    # result = (images)
    return flavors

def generate_flavor_id(ram,vcpus,disk):
    ram = int(ram)
    vcpus = int(vcpus)
    disk = int(disk)
    flavor_id = "%02d%02d%03d" % (vcpus, ram, disk)
    return flavor_id

# use the admin user to create the flavor
def create_flavor(ram, vcpus,disk, ephemeral=0, swap=0, rxtx_factor=1.0, is_public=True):
    username = "adminliberty"
    password = "558d571e9dec51a50689"   
    print ("create flavor")
    version = 2  # settings.NOVA_VERSION
    auth_url = 'http://vsusnjhhdiosconvip:5000/v2.0'  # settings.AUTH_URL

    nova = client.Client(version, username, password, username, auth_url, connection_pool=True)

    print ("login done")
    flavor_id = generate_flavor_id(ram,vcpus,disk)
    ram = int(ram)*1024
    new_flavor = nova.flavors.create(flavor_id, ram, vcpus, disk, flavor_id, ephemeral, swap, rxtx_factor, is_public)
    return new_flavor

# Createing Vm for user:
# create_vm('testvm','ubuntu/centos7', 'description', 'NAMNJ001', username,password)
# image is the name of the volume template. could be ubuntu, centos and so on
def create_vm(vm_name, image,ram,vcpus,disk, description, availability_zone, username, password):
    # cinder = cinderAuth
    # TODO: Generate VM Flavor model if needed, due to billing information.
    # TODO: Generate flavor id, based on hardware config.py

    # flavor ={"vpcu": 1, "RAM":1, "disk":20}
    print("username", username) 
    nova = login_nova_client(username, password)
    flavor_id = generate_flavor_id(ram,vcpus,disk)
    try:
        curr_flavor = nova.flavors.find(id=flavor_id)
    except FlavorNotFound:
        # create flavor in the OS_db
        # create(name, ram, vcpus, disk, flavorid='auto', ephemeral=0, swap=0, rxtx_factor=1.0, is_public=True)
        print ("in")
	curr_flavor = create_flavor(ram,vcpus,disk)
    print("flvaor found.")
    vol_source_id = cinder.volumes.find(name=image).id
    print("Tryinh to create volume")
    new_vol_id = cinderMain(cinder, size=curr_flavor.disk, name=vm_name, description=description, availability_zone=availability_zone, vol_source_id=vol_source_id, username=username)

    block_dev_mapping = {'vda': new_vol_id}
    print("trying to craete vm")
    instance = nova.servers.create(name=vm_name, flavor=curr_flavor, image='', availability_zone=availability_zone, block_device_mapping=block_dev_mapping)
    create_errors = 0
    while instance.status != "ACTIVE":
        print("inside while loop")
        instance = nova.servers.find(id=instance.id)
        if instance.status == "BUILD":
            print("server is still builing")
            time.sleep(5)
            print ("after 5s")
        if instance.status == "ERROR" and instance.fault["message"] == 'No valid host was found. There are not enough hosts available.':
            #delete the errored server first
            print("deleting server cause error")
            nova.servers.delete(instance.id)

            # create the new server
            print("creating again after errro.")
            instance = nova.servers.create(name=vm_name, flavor=curr_flavor, image='', availability_zone=availability_zone, block_device_mapping=block_dev_mapping)
            create_errors += 1
            if create_errors > 4:
                # TODO: send sentry or bug snag
                return False
    print("VM Creation return.")
    return instance

def get_port(uuid, hypervisor_ip):
    # TODO: use libvirt library to remote access to hypervior and get the port
    #hypervisor_ip = get_hypervisor_ip(uuid)
    conn = libvirt.openReadOnly("qemu+ssh://"+hypervisor_ip+":14981/system")
    dom = conn.lookupByUUIDString(uuid)
    root = ET.fromstring(dom.XMLDesc())
    devices = root.find("devices")
    graphics = devices.find("graphics")
    port = graphics.attrib['port']
    print ("vm",uuid, "port :", port)
    # TODO: exeption?
    return port

def doQuery_nova(query):
    #query = "select host from instances where uuid = '58bfceab-c372-44cd-8126-0917283290ff'"
    print("access to novaliberty db")
    host = "192.168.2.23"
    user = "novaliberty"
    passwd = "278a805a2da5aa92cdcd"
    database = "novaliberty"
    db = MySQLdb.connect(host, user, passwd, database)
    cur = db.cursor()
    cur.execute(query)
    row = cur.fetchone()
    result= ""
    if row is not None:
        result = row[0]
        print (result)
    else:
        result = "host not found"
    db.close()
    # this result is the DNS name stored in the DB (psusnjhhdlc7ioscom002). not sure if the websockity can resolve this dns name
    return result


def get_hypervisor_ip(uuid):
    # TODO: connect to OS db and get the hypervisor ip
    # nova db, instances table
    print ("insdide get hyper viros ip for {0}".format(uuid))
    ip_query = "select host from instances where uuid = '{0}'".format(uuid)
    print (ip_query)
    hypervisor_ip = doQuery_nova(ip_query)
    if hypervisor_ip == "host not found":
        # TODO: couldn't find hypervisor IP, notice user
        return False
    else:
        return hypervisor_ip


def connect_db(username, password, url, database):
    conn = MySQLdb.connect(url, username, password, database)
    return conn


# Insert data in Database
def run_query(conn, query):
    cur = conn.cursor()
    cur.execute(query)
    conn.commit()
    conn.close()


def add_ip_and_port(token_hash, ip, port):
    print ("*************helper, write to db*")
    conn = connect_db(username="vncuser", password="systemongrid", url="192.168.2.17", database="VNCConnection")
    query_db = "INSERT INTO vnc_details VALUES ('{0}', '{1}', '{2}')".format(token_hash, ip, port)
    print ("insert to db",query_db)
    run_query(conn=conn, query=query_db)

if __name__ == "__main__":
    username = raw_input("Please enter username:")
    password = raw_input("Please enter password:")
    vm_name = raw_input("Please enter server name:")
    #get_vm_instances_of_user(username, password)
    get_vm_server_by_id(vm_id, username, password)
