from django.conf.urls import patterns, url, include

urlpatterns = patterns('',
    url(r'^auth/', include('djoser.urls.authtoken')),
    url(r'^docs/', include('rest_framework_swagger.urls')),
    url(r'^vms/', include('Openstack_logic.urls')),
)
