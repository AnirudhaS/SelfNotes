from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
#from django.utils import simplejson
from rest_framework import permissions, status, response, views
from djoser.models import BillingHistory, User
from djoser.openstack_api import get_vm_instances_of_user, get_vm_server_by_name, unpause_vm_server, pause_vm_server,get_all_images , get_all_flavors , create_vm 


class AmountDue(APIView):
    def get(self, request):
	username = request.user.username
	user = User.objects.filter(username=username)
	return Response(data=user.amount_due, status=status.HTTP_200_OK)

class BillView(APIView):
    def get(self, request, id):
        bill = BillingHistory.objects.filter(id=id)[0]
        data = {}
        data["time"] = bill.created_at.strftime("%a %b %d %H:%M:%S %Y")
        data["amount"] = bill.amount
        data["description"] = bill.description
	return Response(data=data, status=status.HTTP_200_OK)


class BillingHistoryView(APIView):
    def get(self, request):
	username = request.user.username
	user = User.objects.filter(username=username)        
	hist = BillingHistory.objects.filter(user=user)
	data = []
	print "username"
	print request.user.username
	if hist:
		for bill in hist:
			d = {}
			d['id'] = bill.id
			d['month'] = bill.created_at.strftime("%B") + " " + str(bill.created_at.year)
			d['description'] = bill.description
			d['total'] = bill.amount
			data.append(d)	
        	return Response(data=data, status=status.HTTP_200_OK)
	else:
		return Response(data="", status=status.HTTP_404_NOT_FOUND)
	        # render(request, "djoser/billing_history.html", {"billing": hist})

# Geting the vm of the requestd user
class MyRESTView(APIView):
    permission_classes = (
 		permissions.IsAuthenticated,
	)
		

    def get(self, request, *args, **kw):
	vm_list = get_vm_instances_of_user(request.user.username, request.user.auth_token.key)
  	return Response(
            data=vm_list,
            status=status.HTTP_200_OK,
        )
#Api end point for creating vm
class Create_Vm(APIView):
    permission_classes = (
 		permissions.IsAuthenticated,
	)
    def get(self, request , *args , **kw):
	vm_name = request.GET.get('arg1' , None)
	image = request.GET.get( 'arg2', None)
	flavor = request.GET.get('arg3',None )
	print vm_name
	creating_vm = create_vm(vm_name , image , flavor , request.user.username, request.user.auth_token.key, *args, **kw )
	return Response(
            data=creating_vm,
            status=status.HTTP_200_OK,
        )
  
#Listing all the avalbull images
class ListImages(APIView):
    permission_classes = (
	permissions.IsAuthenticated,
)
    def get(self , request , *args , **kw):
        imgs = get_all_images (request.user.username, request.user.auth_token.key)
	#data = simplejson.dumps(imgs)
	return Response(
	   data = imgs , 
	   status=status.HTTP_200_OK,

			)
#Listing all the avalbull Flavers
class ListFlavors(APIView):
    permission_classes = (
	permissions.IsAuthenticated,
)
   
    def get(self , request , *args , **kw):
        flav = get_all_flavors (request.user.username, request.user.auth_token.key)
        #data = simplejson.dumps(imgs)
        return Response(
           data = flav,
           status=status.HTTP_200_OK,

                        )



# Start or Pause the vm based on the state of the vm
class StartVmsServer(APIView):
    permission_classes = (
 		permissions.IsAuthenticated,
	)
		

    def get(self, request, *args, **kw):
	vm_server_name = request.GET.get('vms_name')
	vm_server = get_vm_server_by_name(vm_server_name,
					  request.user.username,
					  request.user.auth_token.key)
	response = unpause_vm_server(vm_server, request.user.username, request.user.auth_token.key)
	resp = {'status': 'success'}
	if response:
	    resp['message'] = 'Server started successfully.'
	else:
	    resp['message'] = 'Server is already in running state.'
  	return Response(
            data=resp,
            status=status.HTTP_200_OK,
        )

class PauseVmsServer(APIView):
    permission_classes = (
 		permissions.IsAuthenticated,
	)
		

    def get(self, request, *args, **kw):
	vm_server_name = request.GET.get('vms_name')
	vm_server = get_vm_server_by_name(vm_server_name,
					  request.user.username,
					  request.user.auth_token.key)
	response = pause_vm_server(vm_server, request.user.username, request.user.auth_token.key)
	resp = {'status': 'success'}
	if response:
	    resp['message'] = 'Server paused successfully.'
	else:
	    resp['message'] = 'Server is already in paused state.'

  	return Response(
            data=resp,
            status=status.HTTP_200_OK,
        )

