from django.contrib.auth.models import AbstractBaseUser, UserManager
from django.contrib.contenttypes.models import ContentType
from django.contrib.contenttypes.fields import GenericForeignKey
from django.core.validators import RegexValidator
from django.db import models
from django.utils import timezone
import datetime
# from datetime import datetime


# class MyMgr(BaseUserManager):
#     def create_user():
# class DBTimestamp(models.Model):
#     created_date = models.DateTimeField(auto_now_add=True)
#     modified_date = models.DateTimeField(auto_now=True)

#     class Meta:
#         abstract = True


class User(AbstractBaseUser):
    phone_regex = RegexValidator(regex=r'^\+?1?\d{9,15}$', message="Phone number must be entered in the format: '+999999999'. Up to 15 digits allowed.")
    USERNAME_FIELD = 'username'
    REQUIRED_FIELDS = ['first_name', 'last_name', 'date_of_birth', 'phone_number', 'email']
    objects = UserManager()

    # objects = MyMgr()
    username = models.CharField(max_length=254, unique=True)
    email = models.EmailField(blank=True, unique=True)
    first_name = models.CharField(max_length=30, blank=True)
    middle_name = models.CharField(max_length=5, blank=True)
    last_name = models.CharField(max_length=30, blank=True)
    address = models.CharField(max_length=254, blank=True)
    date_of_birth = models.DateField()
    phone_number = models.CharField(validators=[phone_regex], max_length=30, blank=True)  # validators should be a list
    date_joined = models.DateTimeField(('date joined'), default=timezone.now)
    is_active = models.BooleanField(default=True)
    is_superuser = models.BooleanField(default=False)
    is_admin = models.BooleanField(default=False)
    is_staff = models.BooleanField(default=False)
    # Billing Information
    credits = models.FloatField(default=0.0)
    amount_due = models.FloatField(default=0.0)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def default_account(self):
        # Query all types of payment methods. No obvious way to do yet.
        return self.ccpayment_set.filter(is_default=True)[0]

    def amount_due(self):
        today = datetime.datetime.now()
        vms = self.vm_set.filter(deleted_status=False, billing_expiry__gt=today)
        amount = 0.00
        for virtual_machine in vms:
            # TODO: Add monthly charge logic
            monthly_charge = virtual_machine.vm_details.monthly
            # TODO: Add daily charge logic
            daily_charge = virtual_machine.vm_details.daily
            if virtual_machine.billing_type == VM.MONTHLY:
                # Created this month.
                if virtual_machine.created_at.month == today.month:
                    start_day = virtual_machine.created_at.day
                    amount += (today.day - start_day) * daily_charge
                else:
                    amount += monthly_charge
            else:
                # Daily VM.
                # We care where the VM is stopped.
                # Same day at 12 noon.
                amount += virtual_machine.running_days * daily_charge

    # Substracts any amount of credits available and makes the payment.
    def charge(self, amount):
        print "Inside charge"
        if self.credits:
            print "Inside if"
            if self.credits >= amount:
                self.credits = self.credits - amount
                # BillingHistory.save()
                self.save()
            else:
                rem_amount = amount - self.credits
                self.credits = 0.00
                self.default_account().make_payment(rem_amount)
            self.save()
        else:
            print "Inside else"
            self.default_account().make_payment(amount)


# Represents mode of payment available to user, like Credit Cards and wire transfer.
class PaymentAccount(models.Model):
    is_default = models.BooleanField(default=False)
    user = models.ForeignKey(User)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True


class CCPayment(PaymentAccount):
    stripe_token = models.CharField(max_length=200)
    expiry_date = models.DateField()

    def make_payment(self, amount):
        print "Payment made."

# stripe.api_key = "sk_test_BQokikJOvBiI2HlWgH4olfQ2"

# # Get the credit card details submitted by the form
# token = request.POST['stripeToken']

# # Create a Customer
# customer = stripe.Customer.create(
#     source=token,
#     description="Example customer"
# )

# # Charge the Customer instead of the card
# stripe.Charge.create(
#     amount=1000, # in cents
#     currency="usd",
#     customer=customer.id
# )

# # YOUR CODE: Save the customer ID and other info in a database for later!

# # YOUR CODE: When it's time to charge the customer again, retrieve the customer ID!

# stripe.Charge.create(
#     amount=1500, # $15.00 this time
#     currency="usd",
#     customer=customer_id # Previously stored, then retrieved
# )


class BillingHistory(models.Model):
    user = models.ForeignKey(User)
    amount = models.FloatField(null=False, default=0.0)
    description = models.TextField(null=False)
    status = models.BooleanField(null=False, default=True)
    # Polymorphic relations. Look into Generic relations in django documentation.
    # PaymentAccount type
    account_type = models.ForeignKey(ContentType, related_name="PaymentAccount")
    account_id = models.PositiveIntegerField()
    account = GenericForeignKey('account_type', 'account_id')
    created_at = models.DateTimeField(default=timezone.now)
    updated_at = models.DateTimeField(auto_now=True)


class VMDetails(models.Model):
    vm_flavor = models.CharField(null=False, max_length=250)
    daily = models.FloatField(null=False)
    monthly = models.FloatField(null=False)
    C12 = models.FloatField(null=False)
    C24 = models.FloatField(null=False)
    created_at = models.DateTimeField(default=timezone.now)
    updated_at = models.DateTimeField(auto_now=True)


class VM(models.Model):
    # VM status
    STOPPED = 0
    RUNNING = 1
    PAUSED = 2
    DELETED = 3
    STATUS = (
        (DELETED, 'Deleted'),
        (RUNNING, 'Running'),
        (PAUSED, 'Paused'),
    )

    # VM's physical location
    NEW_JERSEY = 0
    CALIFORNIA = 1
    LOCATION = (
        (NEW_JERSEY, 'NEW_JERSEY'),
        (CALIFORNIA, 'CALIFORNIA')
    )

    DAILY = 0
    MONTHLY = 1
    COMMITMENT = 2
    BILLING_TYPE = (
        (DAILY, 'Daily'),
        (MONTHLY, 'Monthly'),
        (COMMITMENT, 'Commitment')
    )

    user = models.ForeignKey(User)
    details = models.ForeignKey(VMDetails)
    status = models.IntegerField(choices=STATUS, default=RUNNING)
    deleted_status = models.BooleanField(default=False)
    openstack_id = models.CharField(null=False, max_length=200)
    location = models.IntegerField(choices=LOCATION)
    billing_type = models.IntegerField(choices=BILLING_TYPE)
    billing_expiry = models.DateTimeField(blank=True, null=True, default=None)
    last_payment = models.DateTimeField(blank=True, null=True, default=None)
    running_days = models.PositiveIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def pause(self):
        # Pause VM logic here.
        print "pause"
        VMActivity.create(self, VM.PAUSED)

    def resume(self):
        # Pause VM logic here.
        print "resume"
        VMActivity.create(self, VM.RUNNING)

    def delete(self):
        # Pause VM logic here.
        print "delete"
        VMActivity.create(self, VM.DELETED)


# TODO: Use NoSQL in the future
class VMActivity(models.Model):

    vm = models.ForeignKey(VM)
    status = models.IntegerField(choices=VM.STATUS)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
