from django.core.exceptions import ImproperlyConfigured


def get(key):
    from django.conf import settings
    defaults = {
        'SEND_ACTIVATION_EMAIL': True,
        'SET_PASSWORD_RETYPE': True,
        'SET_USERNAME_RETYPE': True,
        'PASSWORD_RESET_CONFIRM_RETYPE': True,
        'ROOT_VIEW_URLS_MAPPING': {},
    }
    defaults.update(getattr(settings, 'DJOSER', {}))
    try:
        return defaults[key]
    except KeyError:
        raise ImproperlyConfigured('Missing settings: DJOSER[\'{}\']'.format(key))