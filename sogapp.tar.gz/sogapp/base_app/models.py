from django.db import models

# Create your models here.


class EmailSubscription(models.Model):
    email = models.CharField(max_length=255, null=False, blank=False)


class JobListings(models.Model):
    title = models.CharField(max_length=150, null=False, blank=False)
    description = models.TextField()
    active = models.BooleanField(default=True)


class JobApplication(models.Model):
    position = models.ForeignKey('JobListings')
    resume = models.FileField(upload_to="resume/")
    description = models.TextField()
