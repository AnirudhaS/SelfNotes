from django.shortcuts import render, render_to_response
from django.template import RequestContext
from library.decorators import *
from library.classes import FlashedRedirect
from library.validators import FormValidator
from base_app import models as base_app_models
from django.views.generic import View
from django.http import HttpResponseNotFound
from django.shortcuts import redirect


@flashable
def home(request):
    print "HOME"
    response_dict = {}
    try:
        response_dict['flash_data'] = request.flash_data
    except:
        pass
    return render_to_response('base_app/home.html', response_dict, RequestContext(request))


@post
def subscribe(request):
    form = request.POST.dict()
    response_dict = {}
    validations = {
        'email': ['is_not_empty:Please enter email', 'is_email:Please enter valid email']
    }
    validator = FormValidator(form, validations)
    validator.validate()
    if validator.has_errors():
        errors = validator.get_errors()
        response_dict['status'] = 'error'
        response_dict['message'] = errors['email']
    else:
        email_subscription = base_app_models.EmailSubscription.objects.filter(email=form['email']).first()
        if email_subscription:
            response_dict['status'] = 'error'
            response_dict['message'] = 'You are already subscribed'
        else:
            email_subscription = base_app_models.EmailSubscription(**validator.get_formdata())
            email_subscription.save()
            response_dict['status'] = 'success'
            response_dict['message'] = 'Thanks for subscription'
    return FlashedRedirect('/', request, response_dict, form)


def joblistings(request):
    # Get all the job listings.

    listings = base_app_models.JobListings.objects.filter(active=True)
    print len(listings)
    return render(request, "base_app/joblistings.html", {"listings": listings})


def all_listings(request):
    listings = base_app_models.JobListings.objects.all()
    return render(request, "base_app/all_listings.html", {"listings": listings})

def delete_listing(request, id):
    base_app_models.JobListings.objects.filter(id=id).delete()
    return redirect("/all_applications")


def post_application(request):
    description = ""
    description += "First Name: " + request.POST.get('first_name')
    description += " Last Name: " + request.POST.get('last_name') + "\n"
    description += " Address: " + request.POST.get('address') + " " + request.POST.get('state') + " " + request.POST.get('zip')
    description += " Email: " + request.POST.get('email') + "\n"
    description += " Cell Phone: " + request.POST.get('cell')
    job_id = request.POST.get('job_id')
    job_listing = base_app_models.JobListings.objects.get(id=job_id)
    resume = request.FILES.get('resume', None)
    application = base_app_models.JobApplication(position=job_listing, description=description, resume=resume)
    application.save()

    return render(request, "base_app/successful_post.html")


class CreateApplication(View):
    def get(self, request):
        # if request.META['REMOTE_ADDR'] == '127.0.0.1':
        #     return HttpResponseNotFound("<h1> Page not found.</h1>")
        return render(request, "base_app/create_listing.html")

    def post(self, request):
        title = request.POST.get('title')
        description = request.POST.get('description')
        appl = base_app_models.JobListings(title=title, description=description)
        appl.save()

        # return render(request, "base_app/create_listing.html")
        return redirect("/all_applications")

# TODO: Add parameters to allow only local access. Or use admin page.
# def post_new_listing(request):
#     return render(request, "base_app/create_listing.html")

# TODO: Only provides listing/<id>. Look into making one class to handle index, get/<id> and post.


class JobListingsView(View):

    def get(self, request, id):
        # Get all the job listings.
        # id = request.GET.get("id")
        print id
        listing = base_app_models.JobListings.objects.filter(id=id, active=True)[0]

        print " title : " + listing.title + " desc: " + listing.description
        desc = listing.description
        listing.description = desc
        job_listing = {}
        job_listing["title"] = listing.title
        job_listing["description"] = listing.description
        job_listing["id"] = listing.id

        print listing.description
        return render(request, "base_app/listing.html", {"listing": job_listing})
