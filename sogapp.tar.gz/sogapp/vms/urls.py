from django.conf.urls import include, url
from vms import virtual_machines
urlpatterns = [
  url(r'^$', virtual_machines.index, name='vm_index'),
  url(r'^new$', virtual_machines.new, name='vm_new'),
  url(r'^create$', virtual_machines.create, name='vm_create'),
  url(r'^edit/(?P<id>[0-9]+)$', virtual_machines.edit, name='vm_edit'),
  url(r'^update/(?P<id>[0-9]+)$', virtual_machines.update, name='vm_update'),
  url(r'^delete/(?P<id>[0-9]+)$', virtual_machines.delete, name='vm_delete'),
]