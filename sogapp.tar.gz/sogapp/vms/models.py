from django.db import models

class VirtualMachine(models.Model):
  host_name = models.CharField(max_length=1000, null=True, blank=True, default='')
  root_password = models.CharField(max_length=1000, null=True, blank=True, default='')
  ram_capacity = models.CharField(max_length=255, null=True, blank=True, default='')
  no_of_cores = models.CharField(max_length=255, null=True, blank=True, default='')
  custom_username = models.CharField(max_length=255, null=True, blank=True, default='')
  custom_password = models.CharField(max_length=255, null=True, blank=True, default='')
  os_version = models.CharField(max_length=255, null=True, blank=True, default='')
  os_type = models.CharField(max_length=255, null=True, blank=True, default='')
  vm_name = models.CharField(max_length=1000, null=True, blank=True, default='')
  ip_address = models.CharField(max_length=100, null=True, blank=True, default='')
  mac_address = models.CharField(max_length=100, null=True, blank=True, default='')
  VM_STATE_OPTIONS = (('start', 'Start'), ('pause', 'Pause'), ('stop', 'Stop'))
  state = models.CharField(max_length=100, null=True, blank=True, choices=VM_STATE_OPTIONS)
