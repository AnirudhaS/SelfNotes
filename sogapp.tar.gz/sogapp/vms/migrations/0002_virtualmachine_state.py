# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('vms', '0001_initial'),
    ]

    operations = [
        migrations.AddField(
            model_name='virtualmachine',
            name='state',
            field=models.CharField(blank=True, max_length=100, null=True, choices=[(b'start', b'Start'), (b'pause', b'Pause'), (b'stop', b'Stop')]),
        ),
    ]
