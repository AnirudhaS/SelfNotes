# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='VirtualMachine',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('host_name', models.CharField(default=b'', max_length=1000, null=True, blank=True)),
                ('root_password', models.CharField(default=b'', max_length=1000, null=True, blank=True)),
                ('ram_capacity', models.CharField(default=b'', max_length=255, null=True, blank=True)),
                ('no_of_cores', models.CharField(default=b'', max_length=255, null=True, blank=True)),
                ('custom_username', models.CharField(default=b'', max_length=255, null=True, blank=True)),
                ('custom_password', models.CharField(default=b'', max_length=255, null=True, blank=True)),
                ('os_version', models.CharField(default=b'', max_length=255, null=True, blank=True)),
                ('os_type', models.CharField(default=b'', max_length=255, null=True, blank=True)),
                ('vm_name', models.CharField(default=b'', max_length=1000, null=True, blank=True)),
                ('ip_address', models.CharField(default=b'', max_length=100, null=True, blank=True)),
                ('mac_address', models.CharField(default=b'', max_length=100, null=True, blank=True)),
            ],
        ),
    ]
