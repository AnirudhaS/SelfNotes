from django.shortcuts import render, render_to_response
from django.template import RequestContext
from vms.models import VirtualMachine
from library.decorators import *
from library.classes import *
from django.views.decorators.csrf import csrf_exempt

@csrf_exempt
@check_token
def index(request):
  virtual_machines = list(VirtualMachine.objects.all())
  return JsonResponse({'virtual_machines' : virtual_machines})

@soguser_only
def new(request):
  return render_to_response('vms/new.html', {}, RequestContext(request))

@soguser_only
@post
def create(request):
  pass

@soguser_only
def edit(request, id):
  pass

@soguser_only
@post
def update(request, id):
  pass

@soguser_only
def delete(request, id):
  pass