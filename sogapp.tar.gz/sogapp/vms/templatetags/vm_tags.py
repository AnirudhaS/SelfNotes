from django import template
register = template.Library()

@register.filter(name="get_css_display")
def get_css_display(vm, btn):
  css_display = 'display: {};'
  if vm.state == btn:
    css_display = css_display.format('none')
  return css_display
  # else
  #   if vm.state == 'start':
  #     css_display = css_display.format()
  #   elif vm.state == 'stop':
  #     css_display = css_display.format()
  #   elif vm.state == 'pause':
  #     css_display = css_display.format()
  # return css_display