from django.http import HttpResponseRedirect
from library.classes import FlashedRedirect, JsonResponse
from django.core.urlresolvers import reverse
from django.contrib.auth import logout
from accounts.models import *

def check_token(action):
  def inner_func(*args, **kwargs):
    request = args[0]
    post_data = request.POST.dict()
    if 'auth_token' in post_data.keys():
      auth_token = AuthToken.objects.filter(token = post_data['auth_token']).first()
      if auth_token is not None:
        request.user = auth_token.user
      else:
        return JsonResponse({'status' : 'error', 'message' : 'Invalid Token'})
    return action(*args, **kwargs)
  return inner_func

def anonymous_only(action):
  def inner_func(*args, **kwargs):
    request = args[0]
    if not request.user.is_anonymous():
      if request.user.is_superuser:
        return HttpResponseRedirect('/')
      else:
        return HttpResponseRedirect('/')
    return action(*args, **kwargs)
  return inner_func

def post(action):
  def inner_func(*args, **kwargs):
    request = args[0]
    if request.method != 'POST':
      return HttpResponseRedirect('/')
    return action(*args, **kwargs)
  return inner_func

def flashable(action):
  def inner_func(*args, **kwargs):
    request = args[0]
    if 'flash_data' in request.session:
      request.flash_data = request.session['flash_data']
      del request.session['flash_data']
    if 'form' in request.session:
      request.form = request.session['form']
      del request.session['form']
    return action(*args, **kwargs)
  return inner_func

def admin_only(action):
  def inner_func(*args, **kwargs):
    request = args[0]
    if not request.user.is_superuser:
      if request.user.is_authenticated():
        return HttpResponseRedirect('/')
      else:
        return HttpResponseRedirect('/')
    return action(*args, **kwargs)
  return inner_func

def soguser_only(action):
  def inner_func(*args, **kwargs):
    request = args[0]
    if request.user.is_superuser:
      return HttpResponseRedirect('/')
    elif not request.user.is_authenticated():
      return HttpResponseRedirect('/accounts/signin')
    return action(*args, **kwargs)
  return inner_func

# def token_user_only(action):
#   def inner_func(*args, **kwargs):
#     request = args[0]
#     if request.user.is_anonymous():
#       return FlashedRedirect(reverse('accounts:signin'), request, {
#         'status' : 'error',
#         'message' : 'Please sign in'
#       })
#     else:
#       try:
#         request.session['usage_token']
#       except:
#         logout(request)
#         return FlashedRedirect(reverse('accounts:signin'), request, {
#             'status' : 'error',
#             'message' : 'Contact Administrator to get you a registration token, then register'
#         })
#     return action(*args, **kwargs)
#   return inner_func


