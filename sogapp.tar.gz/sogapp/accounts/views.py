from django.shortcuts import render, render_to_response
from django.http import HttpResponseRedirect
from django.template import RequestContext
from library.decorators import *
from library.classes import *
from accounts.models import SogUser, AuthToken
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth.models import User
from django.contrib.auth import authenticate
from library.validators import FormValidator

@csrf_exempt
def signup_post(request):
  post_data = request.POST.dict()
  validations = {
    'first_name' : 'is_not_empty:Please enter First name',
    'last_name' : 'is_not_empty:Please enter Last name',
    'username' : 'is_not_empty:Please enter Username',
    'email' : 'is_not_empty:Please enter email',
    'password' : ['is_not_empty:Please enter password', 'is_password_confirmed:Password and confirmed Password does not match'],
    'password_confirmation' : 'is_not_empty:Please confirm password',
    'phone_number' : 'is_not_empty:Please enter Phone number'
  }
  validator = FormValidator(post_data, validations)

  validator.validate()
  if validator.has_errors():
    errors = validator.get_errors()
    response_dict = {'status' : 'error', 'message' : 'Form contains errors',  'errors': errors}
  else:
    username = post_data['username']
    email = post_data['email']
    password = post_data['password']
    user = User.objects.create_user(username, email, password, first_name=post_data['first_name'], last_name=post_data['last_name'])
    sog_user = SogUser(**{'middle_name' : post_data['middle_name'], 'phone_number' : post_data['phone_number'], 'user_id' : user.id})
    sog_user.save()
    response_dict = {
      'status' : 'success',
      'message' : 'You have successfully registered'
    }
  return JsonResponse(response_dict)

@csrf_exempt
def signin_post(request):
  post_data = request.POST.dict()
  email = post_data['email']
  password = post_data['password']

  user = User.objects.filter(email=email).first()
  if user is None:
    response_dict = {
      'status' : 'error',
      'message' : 'Invalid Email or Password'
    }
  else:
    username = user.username
    user = authenticate(username=username, password=password)
    if user is not None:
      auth_token = AuthToken.create_token(user)
      response_dict = {
        'status' : 'success',
        'message' : 'You are logged in successfully',
        'auth_token' : auth_token.token,
        'user' : {
          'first_name' : user.first_name,
          'last_name' : user.last_name,
          'email' : user.email,
          'username' : user.username
        }
      }
    else:
      response_dict = {
        'status' : 'error',
        'message' : 'Invalid Email or Password'
      }
  return JsonResponse(response_dict)



@csrf_exempt
def signout(request):
  token = request.POST.get('auth_token')
  auth_token = AuthToken.objects.filter(token=token).first()
  if auth_token is not None:
    auth_token.delete()
  response_dict = {
    'status' : 'success',
    'message' : 'You are successfully signed out'
  }
  return JsonResponse(response_dict)
