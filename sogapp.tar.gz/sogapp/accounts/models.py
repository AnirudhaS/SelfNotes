from django.db import models
from django.contrib.auth.models import User
from django.db.models import Q
import uuid

class SogUser(models.Model):
  user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='sog_user')
  middle_name = models.CharField(max_length=255, null=True, blank=True, default='')
  phone_number = models.CharField(max_length=255, null=True, blank=True, default='')
  created_at = models.DateTimeField(auto_now_add=True)
  updated_at = models.DateTimeField(auto_now=True)

class AuthToken(models.Model):
  user = models.ForeignKey(User, related_name='auth_tokens')
  token = models.CharField(max_length=255, null=False, blank=False)
  created_at = models.DateTimeField(auto_now_add=True)
  updated_at = models.DateTimeField(auto_now=True)

  @classmethod
  def create_token(cls, user):
    auth_token = AuthToken()
    auth_token.user = user
    auth_token.token = uuid.uuid4().hex
    auth_token.save()
    return auth_token

