# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import datetime
from django.utils.timezone import utc
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        ('accounts', '0001_initial'),
    ]

    operations = [
        migrations.CreateModel(
            name='AuthToken',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('token', models.CharField(max_length=255)),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
            ],
        ),
        migrations.AddField(
            model_name='soguser',
            name='created_at',
            field=models.DateTimeField(default=datetime.datetime(2015, 11, 5, 18, 24, 45, 137828, tzinfo=utc), auto_now_add=True),
            preserve_default=False,
        ),
        migrations.AddField(
            model_name='soguser',
            name='updated_at',
            field=models.DateTimeField(default=datetime.datetime(2015, 11, 5, 18, 24, 58, 568095, tzinfo=utc), auto_now=True),
            preserve_default=False,
        ),
        migrations.AlterField(
            model_name='soguser',
            name='user',
            field=models.OneToOneField(related_name='sog_user', to=settings.AUTH_USER_MODEL),
        ),
        migrations.AddField(
            model_name='authtoken',
            name='user',
            field=models.ForeignKey(related_name='auth_tokens', to='accounts.SogUser'),
        ),
    ]
