$(document).on("click", ".vm-delete-action", function(){
  var is_confirmed = confirm("Do you really want to delete this VM?");
  if(is_confirmed == true){
    var $this = $(this);
    var url = $this.data("href");
    var vmname = $this.data("vmname");
    $.ajax({
      url: url,
      data: {"vmname" : vmname},
      type: "post",
      success: function(retdata){
        if(retdata.status == "success"){
          var $tr = $this.closest("tr");
          $tr.remove();
        }
      }
    });
  }
});
$(document).on("click", ".vm-state-action", function(){
  var $this = $(this);
  var setstate = $this.data("setstate");
  var url = '';
  var vmname = $this.data("vmname");
  var nextstateinfo = '';
  var oldbtntext = '';
  var newbtntext = '';
  switch(setstate){
    case "start":
      url = "/vm/state/start"
      nextstateinfo = "Running"
      oldbtntext = "Start";
      newbtntext = "Starting..."
      break;
    case "pause":
      url = "/vm/state/pause"
      nextstateinfo = "Paused"
      oldbtntext = "Pause"
      newbtntext = "Pausing..."
      break;
    case "resume":
      url = "/vm/state/resume"
      nextstateinfo = "Running"
      oldbtntext = "Resume"
      newbtntext = "Resuming..."
      break;
    case "stop":
      url = "/vm/state/stop"
      nextstateinfo = "Shut Off"
      oldbtntext = "Stop"
      newbtntext = "Stopping..."
      break;
  }
  $this.html(newbtntext);
  $.ajax({
    url: url,
    type: "post",
    data: {'vmname' : vmname},
    success: function(retdata){
      if(retdata.status == "success"){
        var $td = $this.closest("td");
        $td.find(".vm-state-action").each(function(){
          if($this.hasClass("showon-" + setstate)){
            $this.show();
          }
          else{
            $this.hide();
          }
          if($this.data("afterstart") != undefined){
            window[$this.data("afterstart")]($this)
          }
        });
        $td.closest("tr").find(".state-info-td").html(nextstateinfo);
        $this.html(oldbtntext);
      }
    }
  });
});

function aftervmstart_newvm_page($start_btn){
  $start_btn.removeClass("vm-state-action");
}