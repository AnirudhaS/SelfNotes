function block_ui($element){
  var htm = "<div class='ui-blocker'></div>"
  $element.prepend(htm)
  $element.find(".ui-blocker").height($element[0].scrollHeight);
}

function unblock_ui($element){
  $element.find(".ui-blocker").remove();
}