$(document).on("ready", function(){
  $("#ram_capacity_touchspin").TouchSpin({
    min: 0,
    max: 5,
    step: 1,
    maxboostedstep: 5,
    initval: 0
  }).on('touchspin.on.startspin', function(a, b){
    var steps = ['512 MB', '1 GB', '2 GB' , '4 GB', '8 GB', '16 GB']
    var $input = $(a.currentTarget);
    var value = $input.val();
    var orig_val = steps[value];
    $("#ram_capacity").val(orig_val);
  });
  $("#ram_capacity_touchspin").hide();
  $("#ram_capacity_touchspin").after("<input type='text' name='ram_capacity' id='ram_capacity' class='form-control text-center' readonly='readonly' value='512 MB'/>");



  $("#hdisk_capacity_touchspin").TouchSpin({
    min: 0,
    max: 5,
    step: 1,
    maxboostedstep: 5,
    initval: 0
  }).on('touchspin.on.startspin', function(a, b){
    var steps = ['10 GB', '20 GB', '40 GB', '80 GB', '160 GB', '320 GB']
    var $input = $(a.currentTarget);
    var value = $input.val();
    var orig_val = steps[value];
    $("#hdisk_capacity").val(orig_val);
  });
  $("#hdisk_capacity_touchspin").hide();
  $("#hdisk_capacity_touchspin").after("<input type='text' name='hdisk_capacity' id='hdisk_capacity' class='form-control text-center' readonly='readonly' value='10 GB'/>");
});

$(document).on("change", "#os_type", function(){
  var $this = $(this);
  var value = $this.val();
  var type_versions = {
    'windows' : [
      {'windows-8.1-pro-x32' : 'Windows 8.1  professional (32 Bit)'},
      {'windows-8.1-pro-x64' : 'Windows 8.1  professional (64 Bit)'},
    ],
    'linux' : [
      {'centos7_64' : 'Centos 7 (64 Bit)'},
      {'fedora_22' : 'Fedora'},
    ],
    'unix' : [
      {'free_bsd' : 'Free BSD'}
    ]
  }
  var type_frequencies = {
    'windows' : [
      {'1.6ghz' : '1.6 Ghz'},
      {'2.0ghz' : '2.0 Ghz'},
      {'2.6ghz' : '2.6 Ghz'},
      {'3.0ghz' : '3.0 Ghz'}
    ],
    'linux' : [
      {'2.6ghz' : '2.6 Ghz'},
      {'2.8ghz' : '2.8 Ghz'},
      {'3.2ghz' : '3.2 Ghz'},
      {'3.6ghz' : '3.6 Ghz'}
    ],
    'unix' : [
      {'1.6ghz' : '1.6 Ghz'},
      {'2.3ghz' : '2.3 Ghz'},
      {'2.5ghz' : '2.5 Ghz'},
      {'3.4ghz' : '3.4 Ghz'}
    ]
  }
  $("#os_version").find("option:not(.select-option)").remove();
  $("#core_frequenty").find("option:not(.select-option)").remove();
  $("#linux_gui_required").closest(".form-group").hide();
  $("#linux_gui_required").prop("checked", false);
  if(value != ''){
    var available_versions = type_versions[value];
    $.each(available_versions, function(){
      $.each(this, function(k,v){
        $("#os_version").append("<option value='" + k + "'>" + v + "</option>");
      });
    });
    var available_frequencies = type_frequencies[value];
    $.each(available_frequencies, function(){
      $.each(this, function(k,v){
        $("#core_frequenty").append("<option value='" + k + "'>" + v + "</option>");
      });
    });
    if(value == 'linux'){
      $("#linux_gui_required").closest(".form-group").show();
      $("#host_name").closest(".form-group").show();
      $("#input_root_password").closest(".form-group").show();
      $("#custom_username").closest(".form-group").show();
      $("#custom_password").closest(".form-group").show();
    }
    if(value == 'windows'){
      $("#host_name").closest(".form-group").hide();
      $("#input_root_password").closest(".form-group").hide();
      $("#custom_username").closest(".form-group").hide();
      $("#custom_password").closest(".form-group").hide();
    }
  }
});

$(document).on("change", "#network_storage_required", function(){
  if($(this).val() == 'yes'){
    $("#network_storage_size").closest(".form-group").show();
    $("#backup_type").closest(".form-group").show();
    $("#backup_size").closest(".form-group").show();
  }
  else{
    $("#network_storage_size").closest(".form-group").hide();
    $("#backup_type").closest(".form-group").hide();
    $("#backup_size").closest(".form-group").hide();
  }
});

$(document).on("submit", ".vm-form", function(e){
  e.preventDefault();
  var $form = $(this);
  $form.hide();
  var data = $form.serialize();
  $.ajax({
    url: '/vm/create',
    data: data,
    type: 'post',
    success: function(retdata){
      if(retdata.status == 'success'){
        $(".message-row .alert").removeClass("alert-danger").addClass("alert-success").html(retdata.message);
        $(".message-row").show();
        $('.error').each(function(){
          $(this).html("");
        });
        $(".progress-row").show();
        // $form.remove();
      }
      else{
        $(".message-row .alert").addClass("alert-danger").removeClass("alert-success").html(retdata.message);
        $(".message-row").show();
        errors = retdata.errors;
        console.log($(".error"))
        $('.error').each(function(){
          var id = $(this).attr("id");
          var ui_key = id.replace('error-', '');
          if(errors[ui_key] == undefined){
            $(this).html("");
          }
          else{
            $(this).html(errors[ui_key]);
          }
        });
      }
    }
  });
});