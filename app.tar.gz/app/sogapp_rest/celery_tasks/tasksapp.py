from __future__ import absolute_import
from celery import task
from djoser.models import User
@task(name='sum')
def addd(x, y):
    return x+y

@task(name='sum-of-2-numbers')
def add(x, y):
    User.objects.filter(is_active=True)
    return x+y

