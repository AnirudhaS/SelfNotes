import datetime
from djoser.models import User, VM, CCPayment, VMDetails, VMActivity

act = VMActivity.objects.create(vm=vm2, VM.PAUSED)
act.created_at = d
act.save()
d = datetime.datetime(month=11, day=20, year=2015)

act2 = VMActivity.objects.create(vm=vm2, VM.RUNNING)
d2 = datetime.datetime(month=11, day=22, year=2015)
act2.created_at = d2
act2.save()
details = VMDetails.objects.create(vm_flavor="testflavor", daily=0.25, monthly=7.50, C12=60.0, C24=120.0)

user = User.objects.create(username="ussdfer1", email="usdsfer1@email.com", first_name="test", middle_name="", last_name="user", address="noaddress", date_of_birth="2010-10-10", phone_number="123456789", is_active=True, is_superuser=False, is_admin=False, is_staff=False)

acc = CCPayment.objects.create(stripe_token="sdfasdgadgadfgadf", expiry_date="2016-10-10", user=user, is_default=True)

# Monthly VM
vm1 = VM.objects.create(user=user, details=details, openstack_id="asdjfha", location=VM.NEW_JERSEY, billing_type=VM.MONTHLY)
vm1.created_at = datetime.datetime(month=11, year=2015, day=15)

vm1.save()

vm2 = VM.objects.create(user=user, details=details, openstack_id="dfasdjfha", location=VM.NEW_JERSEY, billing_type=VM.DAILY)
vm2.created_at = datetime.datetime(month=11, year=2015, day=18)
vm2.save()
