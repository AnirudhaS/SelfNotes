from novaclient import client

#from django.conf import settings

#Createing Method for login the current user in Nova API

def login_nova_client(username, password):

    version = 2 #settings.NOVA_VERSION
    auth_url = 'http://vsusnjhhdiosconvip:5000/v2.0' #settings.AUTH_URL

    nova = client.Client(version, username, password, username, auth_url, connection_pool=True)
    return nova

#Get the vm for Requested User
def get_vm_instances_of_user(username, password):
    nova = login_nova_client(username, password)
    vm_servers = nova.servers.list()
    flavors = nova.flavors.list()
    vm_servers_dict = []
    for vm_server in vm_servers:
        vm_servers_dict.append(get_vm_server_details(vm_server, username, flavors))
    return vm_servers_dict

#Geting the vm detatils 
def get_vm_server_details(vm_server, username, flavors=[]):
    attr = {}
    attr['status'] = vm_server.status
    attr['name'] = vm_server.name
    flavor = vm_server.flavor['id']
    for f in flavors:
        if f.id == flavor:
	    attr['vcpus'] = f.vcpus
	    attr['ram'] = f.ram
	    attr['disk'] = f.disk
    return attr
#Geting Vm based on name of the Vm
def get_vm_server_by_name(vm_server_name, username, password):
    nova = login_nova_client(username, password)
    vm_servers = nova.servers.list(search_opts={'name': vm_server_name})
    return vm_servers[0]
#Pauseing the vm
def pause_vm_server(vm_server, username, password):
    nova = login_nova_client(username, password)
    if vm_server.status != "PAUSED":
        nova.servers.pause(vm_server)
	return True
    else:
	return False
        print "Throw exception"
#UnPauseing the Vm        

def unpause_vm_server(vm_server, username, password):
    nova = login_nova_client(username, password)
    if vm_server.status == "PAUSED":
        nova.servers.unpause(vm_server)
	return True
    else:
	return False
        print "Throw exception"
#Deleteing the VM
def delete_vm_server(vm_server, username, password):
    nova = login_nova_client(username, password)
    nova.servers.delete(vm_server)

def rename_vm_server(vm_server, new_name, username, password):
    nova = login_nova_client(username, password)
    nova.servers.update(vm_server, new_name)

# Geting all the available Images
def get_all_images(username,password):
    nova = login_nova_client(username , password)
    images = [(x.name , x.id) for x in nova.images.list()]
    # result = (images)
    return images

# Getting the all the available
def get_all_flavors(username,password):
    nova = login_nova_client(username , password)
    #flavors = nova.flavors.list()
    flavors  = [(x.name , x.id) for x in nova.flavors.list()]
    # result = (images)
    return flavors
# Createing Vm for user:
def create_vm(vm_name , image , flavor , username , password):
    nova = login_nova_client(username, password)
    #image = nova_client.images.find(name=vm_name)
    #flavor = nova_client.flavors.find(name=flavor)
    instance = nova.servers.create(vm_name, image , flavor)
    print("Sleeping for 5s after create command")
    time.sleep(5)
    print("List of VMs")
    print(nova_client.servers.list())
    return instance



if __name__ == "__main__":
    username = raw_input("Please enter username:")
    password = raw_input("Please enter password:")
    vm_name = raw_input("Please enter server name:")
    #get_vm_instances_of_user(username, password)
    get_vm_server_by_name(vm_name, username, password)
