import datetime
from djoser.models import VM, User
from django.db.models import Q
from celery import task


@task()
def test_task():
    print "run test."


# Run monthly 28th of every month
@task(name='monthly-billing')
def show_me_the_money():

    today = datetime.now()
    all_users = User.objects.all()
    # TODO: Add billing expiry to this.
    # TODO: Add description variable for every billing item.
    for user in all_users:
        vms = user.vm_set.filter(deleted_status=False, billing_expiry__gt=today)
        amount = 0.00
        for virtual_machine in vms:
            # TODO: Add monthly charge logic
            monthly_charge = virtual_machine.vm_details.monthly
            # TODO: Add daily charge logic
            daily_charge = virtual_machine.vm_details.daily
            if virtual_machine.billing_type == VM.MONTHLY:
                # Created this month.
                if virtual_machine.created_at.month == today.month:
                    start_day = virtual_machine.created_at.day
                    amount += (today.day - start_day) * daily_charge
                else:
                    amount += monthly_charge
            else:
                # Daily VM.
                # We care where the VM is stopped.
                # Same day at 12 noon.
                # Reset running days to 0 here.
                amount += virtual_machine.running_days * daily_charge
                virtual_machine.running_days = 0
                virtual_machine.save()
            user.charge(amount)

    # # TODO: Add billing expiry logic - if beyond billing expiry, bill set it as null and bill the monthly amount.
    # vm_monthly = VM.objects.filter(billing_type=VM.MONTHLY, deleted_status=False)
    # today = datetime.now()

    # for virtual_machine in vm_monthly:
    #     user = virtual_machine.user
    #     amount = 0.00
    #     if virtual_machine.created_at.month == today.month:
    #         # Calculate Number of days.
    #         start_day = virtual_machine.created_at.day
    #         amount = (today.day - start_day) * 0.25
    #         # charge the user
    #     else:
    #         # charge user the monthly amount.
    #         amount
    #         print "Normal Monthly Charge"
    #     user.charge(amount)

    # vm_daily = VM.objects.filter(billing_type=VM.DAILY, deleted_status=False)

    # for virtual_machine in vm_daily:
    #     # creation_day = virtual_machine.created_at.hour > (12 am on virtual_machine.created_at.day) ? (virtual_machine.created_at + 1 at 12.00 am / 2400) : (virtual_machine.created_at)
    #     today = datetime.now() - creation_day()  # In number of days.
    #     virtual_machine.user.charge(today * 0.50)


@task(name='daily-update')
def update_vm_table():

    all_vms = VM.objects.filter(status=VM.DELETED)
    this_month = datetime.datetime.now().month
    today = datetime.datetime.now()

    # Updated VM.deleted_status for the VM. Refer to the model for details.
    for virtual_machine in all_vms:
        if virtual_machine.updated_at.month is not this_month:
            virtual_machine.deleted_status = True
            virtual_machine.save()

    # Update VM.running_days
    all_vms = VM.objects.filter(~Q(status=VM.DELETED))

    for virtual_machine in all_vms:
        if virtual_machine.status == VM.RUNNING:
            virtual_machine.running_days += 1
        else:
            # Get activity log for yesterday. Filter them by day.
            # If paused today, then increment. Else don't.
            yesterday = datetime.datetime.now() - datetime.timedelta(days=1)
            virtual_machine.vmactivity_set.filter(create_at=yesterday)

            activity = virtual_machine.vmactivity_set.all().order_by('-created_at')[0]
            if activity.created_at.date() is today.date() and activity.status is VM.PAUSED: virtual_machine.running_days += 1
        virtual_machine.save()
