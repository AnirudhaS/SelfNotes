from django.conf.urls import patterns, url, include
from testapp import views
urlpatterns = patterns('',
    url(r'^auth/', include('djoser.urls.authtoken')),
    url(r'^docs/', include('rest_framework_swagger.urls')),
    url(r'^vms/', include('testapp.urls')),
    url(r'^billing_history/', views.billing_history)
)
