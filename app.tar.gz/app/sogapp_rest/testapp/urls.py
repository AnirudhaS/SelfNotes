from django.conf.urls import patterns, url, include

from testapp import views

urlpatterns = patterns('',
    url(r'^$', views.MyRESTView.as_view()),
    url(r'^start_vms/$', views.StartVmsServer.as_view()),
    url(r'^pause_vms/$', views.PauseVmsServer.as_view()),
    url(r'^images/$', views.ListImages.as_view()),
    url(r'^flavors/$', views.ListFlavors.as_view()),
    url(r'^createvm/$', views.Create_Vm.as_view()),
    url(r'^billing_history/$', views.billing_history)
)
