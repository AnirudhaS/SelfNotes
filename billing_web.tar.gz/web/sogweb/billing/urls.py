from django.conf.urls import include, url
from billing import views

urlpatterns = [
    url(r'^update/$', views.UpdateCCInformation.as_view()),
]
