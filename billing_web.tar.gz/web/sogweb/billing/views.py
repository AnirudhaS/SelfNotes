from django.shortcuts import render
from django.views.generic import TemplateView

from django.http import HttpResponse
from django.views.generic import View

# Create your views here.


class UpdateCCInformation(View):

    def get(self, request):
        return render(request, "billing/update_cc.html")

    def post(self, request):
        return HttpResponse("success")
