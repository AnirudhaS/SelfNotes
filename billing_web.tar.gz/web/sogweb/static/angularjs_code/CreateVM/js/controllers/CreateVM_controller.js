CreateVM_app.controller('CreateVM_controller',function($scope,$window){
        $scope.VMName = "";
        $scope.WorkStation = "";
        $scope.Server = "";
        $scope.Memory = "";
        $scope.Storage = "";
        $scope.VCPU = "";
        $scope.MemoryModel = 1;
        $scope.StorageModel = 20;
        $scope.VCPUModel = 1;
        $scope.DataCenterLocation = "California";
        $scope.Longitude = "";
        $scope.Latitude = "";

        $scope.IncreaseMemory = function(){
        	if($scope.MemoryModel == 8)
        		return;
        	$scope.MemoryModel*=2;
        }
        $scope.DecreaseMemory = function(){
 		if($scope.MemoryModel == 1)
        		return;
        	$scope.MemoryModel/=2;
        }
        $scope.IncreaseStorage = function(){
        	if($scope.StorageModel == 120)
        		return;
        	$scope.StorageModel+=20;
        }
        $scope.DecreaseStorage = function(){
        	if($scope.StorageModel == 20)
        		return;
        	$scope.StorageModel-=20;
        }
        $scope.IncreaseVCPU = function(){
        	if($scope.VCPUModel == 8)
        		return;
        	$scope.VCPUModel*=2;
        }
        $scope.DecreaseVCPU = function(){
        	if($scope.VCPUModel == 1)
        		return;
        	$scope.VCPUModel/=2;
        }
        $scope.Model1 = function(){
           $scope.Memory = 4;
           $scope.Storage = 60;
           $scope.VCPU = 2;
        }
        $scope.Model2 = function(){
           $scope.Memory = 8;
           $scope.Storage = 80;
           $scope.VCPU = 4;
        }
        $scope.Model3 = function(){
           $scope.Memory = $scope.MemoryModel;
           $scope.Storage = $scope.StorageModel;
           $scope.VCPU = $scope.VCPUModel;
        }
        $window.navigator.geolocation.getCurrentPosition(function(position){
                var lat = position.coords.latitude;
                var lng = position.coords.longitude;
        $scope.$apply(function(){
              $scope.lat = lat;
              $scope.lng = lng;
        });
       });

});