listVMS.directive('vmInfo', ['$http', function($http) { 
  return { 
    restrict: 'E', 
    scope: { 
      info: '=', 
      rmv: '=',
      vnc: '=',
    }, 
    templateUrl: '/static/angularjs_code/vms_cc/views/vmInfo.html',

    link: function(scope, element, attrs) {
      if(scope.info.status == 'ACTIVE'){
        scope.buttonText = 'Pause';
        scope.act = 'pause';
      }
      else{
        scope.buttonText = 'Start';
        scope.act = 'play';        
      }

      scope.sos = function() {
	sosUrl = '/cc/sos_vms/?vms_id='+scope.info.vm_id+'&new_status='+scope.act
 	$http({
    	    method: 'get',
    	    url: sosUrl
    	}).then(function successCallback(response) {
          resp = response.data
	  if (resp['status'] == 'success'){
            if(scope.info.status == 'PAUSED'){
              scope.info.status = "ACTIVE";
              scope.buttonText = "Pause";
              scope.act = "pause";
            }
            else{
              scope.info.status = "PAUSED";
              scope.buttonText = "Start";
              scope.act = "play";
            }
	  }
	  else{
	    alert(resp['message']);
	  }
    	}, function errorCallback(response) {
          	//some error here ?
    	});
     }
    },
  };
}]);
