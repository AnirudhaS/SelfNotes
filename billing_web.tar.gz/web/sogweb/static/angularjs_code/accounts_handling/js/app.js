var signin_app = angular.module('signIn', []);
var signup_app = angular.module('signUp', ['ui.validate', 'ngSanitize', ]);
var updateme_app = angular.module('updateMe', []);
var changepwd_app = angular.module('changePwd', []);
var forgetpwd_app = angular.module('forgetPwd', []);
var changeusername_app = angular.module('changeUsername', []);



