changepwd_app.controller('changepwdCtrl', function($scope, $http) {
  $scope.password = {
    new_password: "",
    re_new_password: "",
    current_password: "",

  };
  $scope.changepwd = function(){
    var xsrf = $("form").serialize();
    console.log(xsrf)
    $http({
      method: 'post',
      url: '/accounts/changepwd',
      data: xsrf,
      headers: {'Content-Type': 'application/x-www-form-urlencoded'}
    }).then(function successCallback(response) {
      if(response['data']['status'] == 200){
        window.location.assign('/cc');
      }
      else{
        $scope.errorMessages = response['data']['non_field_errors']
      }
    });
  }

}).config(function($interpolateProvider) {
  $interpolateProvider.startSymbol('[[');
  $interpolateProvider.endSymbol(']]');
});
