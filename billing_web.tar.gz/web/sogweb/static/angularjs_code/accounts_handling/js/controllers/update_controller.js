updateme_app.controller('updateMeCtrl', ['$scope', '$http', function($scope, $http) {

    $scope.profiledata = {
        userfirstname:"",
        usermiddlename : "",
        userlastname : "",
        useremail : "",
        phonecountrycode : "",
        phonenumber : "",
        address1 : "",
        address2 : "",
        state : "",
        country : "",
        zipcode : "",
    };

    $scope.errorMessages = '';
    

    $scope.updateInfo = function() {
        var xsrf = $("form").serialize();
        console.log(xsrf)
    $http({
            method: 'post',
            url: '/accounts/updateme',
            data: xsrf,
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        }).then(function successCallback(response) {
            if(response.data['status'] == 'success'){
                window.location.assign('/cc');
            }
            else{
                angular.forEach(response.data['errors'], function(value, key) {
                    var model = $parse('error_'+key);
                    model.assign($scope, value);
                });
            }
        }, function errorCallback(response) {
            console.log("someting is wrong .");
        });
    }
}]).config(function($interpolateProvider) {
    $interpolateProvider.startSymbol('[[');
    $interpolateProvider.endSymbol(']]');
});
