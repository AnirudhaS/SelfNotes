forgetpwd_app.controller('forgetpwdCtrl', function($scope, $http) {
  $scope.email = '';
  $scope.errorMessages = '';

  $scope.forgetpwd = function(){
    var xsrf = $("form").serialize();
    console.log(xsrf)
    $http({
      method: 'post',
      url: '/accounts/forgetpwd',
      data: xsrf,
      headers: {'Content-Type': 'application/x-www-form-urlencoded'}
    }).then(function successCallback(response) {
      if(response['data']['status'] == 'success'){
        window.location.assign('/accounts');
      }
      else{
        $scope.errorMessages = response['data']['non_field_errors']
      }
    });
  }

}).config(function($interpolateProvider) {
  $interpolateProvider.startSymbol('[[');
  $interpolateProvider.endSymbol(']]');
});
