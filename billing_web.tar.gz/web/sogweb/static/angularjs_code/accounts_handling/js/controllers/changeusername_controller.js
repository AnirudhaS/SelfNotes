changeusername_app.controller('changeusernameCtrl', function($scope, $http) {
  $scope.usernamechage = {
    current_password: "",
    new_username: "",
    re_new_username: "",


  };
  $scope.chusername = function(){
    var xsrf = $("form").serialize();
    console.log(xsrf)
    $http({
      method: 'post',
      url: '/accounts/chusername',
      data: xsrf,
      headers: {'Content-Type': 'application/x-www-form-urlencoded'}
    }).then(function successCallback(response) {
      if(response['data']['status'] == 'success'){
        window.location.assign('/cc');
      }
      else{
        $scope.errorMessages = response['data']['non_field_errors']
      }
    });
  }

}).config(function($interpolateProvider) {
  $interpolateProvider.startSymbol('[[');
  $interpolateProvider.endSymbol(']]');
});
