$(document).ready(function(){
	$("#PersonalInfo").hide();
	$("#ChangePassword").hide();
	$("#CreditCardInfo").hide();
	$("#PersonalInfoButton").click(function(){
		if($("#PersonalInfo").css('display') == 'none')
		    $("#PersonalInfo").show();
		else
			$("#PersonalInfo").hide();
		$("#ChangePassword").hide();
		$("#CreditCardInfo").hide();
	});
	$("#ChangePasswordButton").click(function(){
		if($("#ChangePassword").css('display') == 'none')
		      $("#ChangePassword").show();
		else
			$("#ChangePassword").hide();
		$("#PersonalInfo").hide();
		$("#CreditCardInfo").hide();
	});
	$("#CreditCardInfoButton").click(function(){
		if($("#CreditCardInfo").css('display') == 'none')
		      $("#CreditCardInfo").show();
		else
			$("#CreditCardInfo").hide();
		$("#PersonalInfo").hide();
		$("#ChangePassword").hide();
		
	});
});