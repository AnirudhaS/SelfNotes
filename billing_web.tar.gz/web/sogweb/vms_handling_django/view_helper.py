"""
Helper module to make request to app server
"""

import requests

from django.conf import settings


class VirtualMachine(object):
    """
    Helper class to get ,update or create  vms app related
    data on sogapp server.
    """

    @classmethod
    def get_user_vms(cls, auth_token):
        """
        This method gets virtual machines of logged in user.
        """

        vmlist_url = '{}vms/'.format(settings.APP_SERVER_BASE_URL)
        payload = {'auth_token': auth_token}
        headers = {
            'Authorization': "Token %s" % (auth_token)
        }

        resp = requests.get(vmlist_url, data=payload, headers=headers)
        response = resp.json()
        return response

    @classmethod
    def start_vms(cls, auth_token, vms_id):
        """
        This method starts given vms server.
        """

        start_vms_url = '{}vms/start_vms/'.format(settings.APP_SERVER_BASE_URL)
        payload = {'vms_id': vms_id}
        headers = {
            'Authorization': "Token %s" % (auth_token)
        }

        resp = requests.get(start_vms_url, params=payload, headers=headers)
        response = resp.json()
        return response

    @classmethod
    def pause_vms(cls, auth_token, vms_id):
        """
        This method pause given vms server.
        """

        pause_vms_url = '{}vms/pause_vms/'.format(settings.APP_SERVER_BASE_URL)
        payload = {'vms_id': vms_id}
        headers = {
            'Authorization': "Token %s" % (auth_token)
        }

        resp = requests.get(pause_vms_url, params=payload, headers=headers)
        response = resp.json()
        return response

    @classmethod
    def delete_vms(cls, auth_token, vms_id):
        """
        This method pause given vms server.
        """

        pause_vms_url = '{}vms/delete_vms/'.format(settings.APP_SERVER_BASE_URL)
        payload = {'vms_id': vms_id}
        headers = {
                'Authorization': "Token %s" % (auth_token)
        }

        resp = requests.get(pause_vms_url, params=payload, headers=headers)
        print(resp)
        response = resp.json()
        return response

    @classmethod
    def get_images(cls, auth_token):
        """
        This method starts given vms server.
        """

        vms_images_url = '{}vms/images/'.format(settings.APP_SERVER_BASE_URL)
        headers = {
                'Authorization': "Token %s" % (auth_token)
        }

        resp = requests.get(vms_images_url, headers=headers)
        response = resp.json()
        return response

    @classmethod
    def get_flavors(cls, auth_token):
        """
        This method starts given vms server.
        """

        vms_flavors_url = '{}vms/flavors/'.format(settings.APP_SERVER_BASE_URL)
        headers = {
                'Authorization': "Token %s" % (auth_token)
        }

        resp = requests.get(vms_flavors_url, headers=headers)
        response = resp.json()
        return response

    @classmethod
    def create_vm(cls, data, auth_token):
        """
            This method authenticate the email and password by calling the
            accounts/signin_post API of the SOGAPP.
        """

        payload = {'data': data}
        headers = {
            'Authorization': "Token %s" % (auth_token)
        }
        print(data)
        createvm_url = '{}vms/createvm/'.format(settings.APP_SERVER_BASE_URL)
        response = requests.post(createvm_url, data=data, headers=headers)
        if response.status_code == 201:
            status = 'success'
        else:
            status = 'error'

        response = response.json()
        response['status'] = status
        return response
    @classmethod
    def access_vm(cls, auth_token, token):
        """
            This method authenticate the email and password by calling the
            accounts/signin_post API of the SOGAPP.
        """
        payload = {'auth_token': auth_token, "uuid": token}
        print("payload: " ,payload)
        headers = {
            'Authorization': "Token %s" % (auth_token)
        }

        print("attempting to get sogapp")
        accessvm_url = '{}vms/accessvm/'.format(settings.APP_SERVER_BASE_URL)
        print("Making sogapp post")
        response = requests.get(accessvm_url, data=payload, headers=headers)
        print("made sogapp post")
        print("------------------------------")
        return response
