"""
Module contains views of accounts application
"""
import logging
from django.template import loader
from django.http import HttpResponse
from django.shortcuts import render
from django.http import HttpResponseRedirect, JsonResponse
from django.core.urlresolvers import reverse
from django.views.decorators.csrf import csrf_exempt
from django.contrib import messages
from django.views.generic import View
from django.utils.decorators import method_decorator
from library.decorators import valid_token_only, credit_card_required
from library.decorators import anonymous_only
from accounts_handling_django.view_helper import User


class Welcome(View):
    """
    View to handle home page.
    """

    def get(self, request):
        """
        This method renders the welcome page.
        """
        return render(request, 'accounts/welcome.html')


class SignUpView(View):
    """
    Class based view to handle signup form
    """

    @method_decorator(anonymous_only)
    def dispatch(self, *args, **kwargs):
        return super(SignUpView, self).dispatch(*args, **kwargs)

    def get(self, request):
        """
        This method will render signup page.
        """

        return render(request, "accounts/signup.html")

    def post(self, request):
        """
        It will call the save method to register the user on success it will
        redirect to activation page and in case of error it will render
        signup page with errors on it.
        """
        post_data = request.POST.dict()
        response_data = User.save(post_data)
        return JsonResponse(response_data)


class SignInView(View):
    """
    View to handle signin request
    """

    @method_decorator(anonymous_only)
    @method_decorator(csrf_exempt)
    def dispatch(self, *args, **kwargs):
        return super(SignInView, self).dispatch(*args, **kwargs)

    def get(self, request):
        """
        Renders just the signin page.
        """

        return render(request, 'accounts/signin.html')

    def post(self, request):
        """
        Calls the authenticate method to login the user on success it will
        redirect to vms/cc page and in case of error
        it will render signin page with errors on it.
        """

        username = request.POST.get('username')
        password = request.POST.get('password')
        resp = User.authenticate(username, password)
        if resp['status'] != 'error':
            auth_token = resp.get('auth_token')
            credit_card_present = True
            user_info = User.get_user_info(auth_token)
            User.login(request, auth_token, user_info, credit_card_present)
            messages.success(request, 'You are successfully signed in')
        return JsonResponse(resp)


class SignOutView(View):
    """"
    View to handle sign out request
    """

    def get(self, request):
        """
        This will call the logout helper method and redirects to signin page.
        """

        messages.success(request, 'You are successfully signed out')
        User.logout(request)
        return HttpResponseRedirect(reverse('accounts:signin'))

class UserInfo(View):
    """
    View to create new virtual machine.
    """

    @method_decorator(credit_card_required)
    def dispatch(self, *args, **kwargs):
        return super(UserInfo, self).dispatch(*args, **kwargs)

    def get(self, request):
        """
        Renders form to Update user info.
        """
        auth_token = request.session['auth_token']
        user_info = User.get_user_info(auth_token)
        print(user_info)
        return JsonResponse(user_info)

class ForgetPwd(View):
    """
    Class based view to handle forget Password
    """

    @method_decorator(anonymous_only)
    def dispatch(self, *args, **kwargs):
        return super(ForgetPwd, self).dispatch(*args, **kwargs)

    def get(self, request):
        """
        This method will render signup page.
        """

        return render(request, "accounts/forgetpwd.html")

    def post(self, request):
        """
        This method will get the email of the User and
        send password forget recovary link to that emall
        """
        post_data = request.POST.dict()
        response_data = User.forgetpwd(post_data)
        return JsonResponse(response_data)        

class UpdateUserInfo(View):
    """
    View to Update User Information
    """

    @method_decorator(credit_card_required)
    def dispatch(self, *args, **kwargs):
        return super(UpdateUserInfo, self).dispatch(*args, **kwargs)

    def get(self, request):
        """
        Renders form to Update user info.
        """
        auth_token = request.session['auth_token']
        user_info = User.get_user_info(auth_token)
        print (user_info)
        template = loader.get_template('accounts/updateuser.html')
        context = {
            'user_info': user_info,
        }
        return HttpResponse(template.render(context , request))

    def post(self, request):
        """
        Update User info
        """
        auth_token = request.session['auth_token']
        post_data = request.POST.dict()
        print post_data
        response_data = User.update_user(post_data, auth_token)
        return JsonResponse(response_data)

class ChangePassword(View):
    """
    View to create new virtual machine.
    """

    @method_decorator(credit_card_required)
    def dispatch(self, *args, **kwargs):
        return super(ChangePassword, self).dispatch(*args, **kwargs)

    def get(self, request):
        
        return render(request, 'accounts/changepassword.html')
    def post(self, request):
        """
        Update User password
        """
        auth_token = request.session['auth_token']
        post_data = request.POST.dict()
        print post_data
        response_data = User.change_password(post_data, auth_token)
        print("reponse_data: {0}".format(response_data))
        return JsonResponse(response_data)

class ChangeUsername(View):
    """
    View to Change Username.
    """

    @method_decorator(valid_token_only)
    def dispatch(self, *args, **kwargs):
        return super(ChangeUsername, self).dispatch(*args, **kwargs)

    def get(self, request):
        
        return render(request, 'accounts/changeusername.html')
    def post(self, request):
        """
        Update User username 
        """
        auth_token = request.session['auth_token']
        post_data = request.POST.dict()
        print post_data
        response_data = User.change_username(post_data, auth_token)
        return JsonResponse(status=response_data["status"])                               


class RenderActivateAccountTemplate(View):
        def get(self, request):
            activation_token = request.GET.get('activation_token')
            return render(request, 'accounts/activation_token.html', {'activation_token': activation_token})


class ActivateAccountView(View):
    """
    Handles request to activate user account.
    """

    def get(self, request, activation_token):
        """
        This method activates the user's account and redirects it to the
        signin page.
        """

        data = {'activation_token': activation_token}
        User.activate_account(data)
        return HttpResponseRedirect(reverse('accounts:signin'))


class SaveCCDetailsView(View):
    """
    Handles request to save gredit card details of user.
    """

    @method_decorator(csrf_exempt)
    def dispatch(self, *args, **kwargs):
        return super(SaveCCDetailsView, self).dispatch(*args, **kwargs)

    def post(self, request):
        """
        It will call the save_cc_details method which will save the
        credit card details for the current user.
        """

        cc_number = request.POST.get('credit_card_number')
        data = {'cc_number': cc_number,
                'auth_token': request.session['auth_token']}
        response = User.save_cc_details(data)
        if response['status'] == 'success':
            request.session['credit_card_present'] = True
            messages.success(request, response['message'])
        else:
            messages.error(request, response['message'])

        return HttpResponseRedirect(reverse('vms:vm_index'))
