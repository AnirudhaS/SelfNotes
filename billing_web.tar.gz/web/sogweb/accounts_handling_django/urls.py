from django.conf.urls import include, url
from accounts_handling_django import views

urlpatterns = [
    url(r'^$',
        views.Welcome.as_view(),
        name='welcome'),
    url(r'^signup$',
        views.SignUpView.as_view(),
        name='signup'),

    url(r'^signin$',
        views.SignInView.as_view(),
        name='signin'),

    url(r'^signout$',
        views.SignOutView.as_view(),
        name='signout'),
    url(r'^forgetpwd$',
        views.ForgetPwd.as_view(),
        name='forgetpwd'),
    url(r'^me$',
        views.UserInfo.as_view(),
        name='me'),
    url(r'^updateme$',
        views.UpdateUserInfo.as_view(),
        name='updateme'),
    url(r'^changepwd$',
        views.ChangePassword.as_view(),
        name='changepwd'),
    url(r'^chusername$',
        views.ChangeUsername.as_view(),
        name='changeusername'),

    url(r'^confirm_token/(?P<activation_token>\w{16})$',
        views.ActivateAccountView.as_view(),
        name='confirm_token'),

    url(r'^activate_account/',
        views.RenderActivateAccountTemplate.as_view(),
        name='activate_account'),

    url(r'^save_cc_details/$',
        views.SaveCCDetailsView.as_view(),
        name='save_cc_details'),
]
