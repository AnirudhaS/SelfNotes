from django import forms
from django.core.validators import ValidationError

class SignInForm(forms.Form):
  email = forms.EmailField(required=True,
			   widget=forms.TextInput(attrs={'type': 'text',
							 'placeholder': 'email',
							 'autocomplete': 'off',
							 'class': 'form-control'}));

  password = forms.CharField(required=True,
		  	     widget=forms.TextInput(attrs={'type': 'password',
                                                           'placeholder': 'password',
                                                           'autocomplete': 'off',
			           			   'class': 'form-control'}))

class SignUpForm(forms.Form):

  first_name = forms.CharField(required=True,
			       max_length=20,
			       help_text="Max length 20 characters;Only alphabets;Not more than two consecutive\
					  letters can be repeated;No special characetrs and number",
		  	       widget=forms.TextInput(attrs={'placeholder': 'First Name',
                                                             'autocomplete': 'off',
			           			     'class': 'form-control',
							     'title': 'First Name'}))

  middle_name = forms.CharField(required=False,
			        max_length=1,
			        help_text="Only Aplphabets allowed, no numbers or special characters;Max length 1 character",
		  	        widget=forms.TextInput(attrs={'placeholder': 'Middle Name',
                                                              'autocomplete': 'off',
			           			      'class': 'form-control',
							      'title': 'Middle Name'}))

  last_name = forms.CharField(required=True,
 		              max_length=20,
			      help_text="Max length 20 characters;Only alphabets;Not more than two consecutive\
					 letters can be repeated;No special characetrs and number",
		  	      widget=forms.TextInput(attrs={'placeholder': 'Last Name',
                                                            'autocomplete': 'off',
 		           			            'class': 'form-control',
							    'title': 'Last Name'}))

  username = forms.CharField(required=True,
 		             max_length=30,
			     help_text="Max length 30 characters;Alphabets,numbers and special characters \
					( underscore '_' dash '-' period '.') allowed;Verify Username is already\
					 present;Can not start with specials characters or numbers;Not more than \
					three conscutive letters can be repeated",
		  	     widget=forms.TextInput(attrs={'placeholder': 'Username',
                                                           'autocomplete': 'off',
 		           			           'class': 'form-control',
							   'title': 'Username'}))

  email = forms.EmailField(required=True,
 		           max_length=20,
			   help_text="Alphabets,numbers,special characters\
				     (@,underscore'_',dash'-',period'.');Max length 50 characters",
			   widget=forms.TextInput(attrs={'type': 'text',
							 'placeholder': 'Email',
							 'autocomplete': 'off',
							 'class': 'form-control'}));

  phone_number = forms.IntegerField(required=True,
				    help_text="Length has 10 digits;Only numbers allowed;\
					       The first 6 digits of the no can not be zero;Verify\
					       if valid number;As soon as number is enterd verfication\
					       code should be  sent via sms;Field to ener the code \
					       and code should be verified",
			   	    widget=forms.TextInput(attrs={'type': 'text',
				  			          'placeholder': 'Phone Number',
							          'autocomplete': 'off',
							          'class': 'form-control'}));

  date_of_birth = forms.DateField(required=True,
			   	  widget=forms.TextInput(attrs={'type': 'text',
				  	 	                'placeholder': 'Date Of Birth',
							        'autocomplete': 'off',
								'onkeydown': 'return false',
							        'class': 'form-control'}));

  address = forms.CharField(required=False,
			    widget=forms.Textarea(attrs={'autocomplete': 'off',
							  'placeholder':'Address',
							  'cols': 57,
							  'rows': 4}));

  password = forms.CharField(required=True,
			     help_text="Length in between 6-20 characters;\
					Two fields:password and confirm password;\
					Alphabets,numbers,special characters allowed;\
					Can not start with special characters or numbers",
		  	     widget=forms.TextInput(attrs={'type': 'password',
                                                           'placeholder': 'Password',
                                                           'autocomplete': 'off',
			           			   'class': 'form-control'}))
  confirm_password = forms.CharField(required=True,
		  	     	     widget=forms.TextInput(attrs={'type': 'password',
                                                           'placeholder': 'Password Confirmation',
                                                           'autocomplete': 'off',
			           			   'class': 'form-control'}))

  def clean(self):
    super(SignUpForm, self).clean()
    password = self.cleaned_data['password']
    confirm_password = self.cleaned_data['confirm_password']
    if password != confirm_password:
      raise ValidationError('Password and confirm password does\'n match.')
