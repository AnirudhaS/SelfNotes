"""
Helper module for views
"""

import uuid
import requests

from django.conf import settings
from django.http import HttpResponse

class User(object):
    """
    Helper class contains which makes request to sog app server.
    """

    @classmethod
    def authenticate(cls, username, password):
        """
        This method authenticate the email and password by calling the
        accounts/signin_post API of the SOGAPP.
        """

        signin_url = '{}auth/login/'.format(settings.APP_SERVER_BASE_URL)
        payload = {'username': username, 'password': password}
        response = requests.post(signin_url, data=payload)
        status_code = response.status_code
        response = response.json()

        if status_code == 200:
            status = 'success'
        else:
            status = 'error'
        response['status'] = status
        return response

    @classmethod
    def is_authenticated(cls, request):
        """
        This method checks whether user_token is present in the current session,
        presence of user_token indicates that the user is authenticated.
        """

        return True if 'user_token' in request.session else False

    @classmethod
    def get_user_info(cls, auth_token):
        """
        """

        get_user_info_url = '{}auth/me/'.format(settings.APP_SERVER_BASE_URL)
        headers = {
            'Authorization': "Token %s" % (auth_token)
        }

        response = requests.get(get_user_info_url, headers=headers)
        status_code = response.status_code
        response = response.json()

        if status_code == 200:
            status = 'success'
        else:
            status = 'error'
        response['status'] = status
        return response

    @classmethod
    def login(cls, request, auth_token, user_info, credit_card_present):
        """
        This method stores the user_token, auth_token, user_info and the
        presense of credit card inside the session.
        """

        if not User.is_authenticated(request):
            request.session['user_token'] = uuid.uuid4().hex
            request.session['auth_token'] = auth_token
            request.session['credit_card_present'] = credit_card_present
            request.session['user'] = user_info

    @classmethod
    def get_user_by_auth_token(cls, auth_token):
        """
        This method calls the get_user API of the SOGAPP which in returns the
        user_info with the help of the provided AuthToken.
        """

        getuser_url = '{}get_user'.format(settings.APP_SERVER_BASE_URL)
        response = requests.post(getuser_url,
                                 data={'auth_token': auth_token}).json()
        user_info = response['user']
        return user_info

    @classmethod
    def save(cls, data):
        """
        This method calls the auth/register post API of the SOGAPP and
        pass the user data that has been filled by the user.
        """

        saveuser_url = '{}auth/register/'.format(settings.APP_SERVER_BASE_URL)
        response = requests.post(saveuser_url, data=data)
        if response.status_code == 201:
            status = 'success'
        else:
            status = 'error'

        response = response.json()
        response['status'] = status
        return response
    @classmethod
    def forgetpwd(cls, data):
        """
        This method calls the auth/register post API of the SOGAPP and
        pass the user data that has been filled by the user.
        """

        forgetpwd_url = '{}auth/password/reset/'.format(settings.APP_SERVER_BASE_URL)
        response = requests.post(forgetpwd_url, data=data)
        if response.status_code == 200:
            status = 'success'
        else:
            status = 'error'

        response = response.json()
        response['status'] = status
        return response 
    @classmethod
    def forgetpwd_conform(cls, data):
        """
        This method calls the auth/register post API of the SOGAPP and
        pass the user data that has been filled by the user.
        """

        forgetpwd_conform_url = '{}auth/password/reset/confirm/'.format(settings.APP_SERVER_BASE_URL)
        response = requests.post(forgetpwd_conform_url, data=data)
        if response.status_code == 200:
            status = 'success'
        else:
            status = 'error'

        response = response.json()
        response['status'] = status
        return response           

    @classmethod
    def update_user(cls ,data,auth_token):
        """
        This method calls the auth/me patch API of the SOGAPP and
        pass the user data and update the user info.
        """
        payload = {'data': data}

        headers = {
            'Authorization': "Token %s" % (auth_token)
        }
        print(data)
        updateuser_url = '{}auth/me/'.format(settings.APP_SERVER_BASE_URL)
        
        response = requests.patch(updateuser_url, data=data, headers=headers)
        if response.status_code == 200:
            status = 'success'
        else:
            status = 'error'

        response = response.json()
        response['status'] = status
        return response
    @classmethod
    def change_password(cls,data,auth_token):
        """
        This method calls the auth/password post API of the SOGAPP and
        change user password
        """


        changepassword_url = '{}auth/password/'.format(settings.APP_SERVER_BASE_URL)
        headers = {
            'Authorization': "Token %s" % (auth_token)
        }
        
        response = requests.post(changepassword_url, data=data, headers=headers)
        
        status_code = response.status_code
        print("status code:{0}".format(status_code))
        #response = response.json()
        #if status_code == 200:
        #    status = 'success'
        #else:
        #    status = 'error'
        #response['status'] = status
        print("abotu to return")
        return {"status": status_code}

    @classmethod
    def change_username(cls,auth_token,data):
        """
        This method calls the auth/username post API of the SOGAPP and
        change user username
        """

        changeusername_url = '{}auth/username/'.format(settings.APP_SERVER_BASE_URL)
        headers = {
            'Authorization': "Token %s" % (auth_token)
        }
        response = requests.post(changeusername_url, data=data, headers=headers)
        if response.status_code == 200:
            status = 'success'
        else:
            status = 'error'

        response = response.json()
        response['status'] = status
        return response            
 
    
    @classmethod
    def logout(cls, request):
        """
        This method calls the accounts/signout API of the SOGAPP only
        if auth_token is present in the current session.
        """

        if 'auth_token' in request.session:
            signout_url = '{}auth/logout/'.format(settings.APP_SERVER_BASE_URL)
        headers = {
            'Authorization': "Token %s" % (request.session['auth_token'])
        }
        requests.post(signout_url, headers=headers)
        request.session.flush()



    
    @classmethod
    def activate_account(cls, data):
        """
        This method calls the accounts/activate_account
        API of the SOGAPP which actually activates the account/user.
        """

        activate_account_url = '{}accounts/activate_account'.format(settings.APP_SERVER_BASE_URL)
        response = requests.post(activate_account_url, data=data)
        return response.json()

    @classmethod
    def save_cc_details(cls, data):
        """
        This method calls the accounts/save_cc/ API of the SOGAPP which
        saves the credit card details in the database.
        """

        save_cc_url = '{}accounts/save_cc/'.format(settings.APP_SERVER_BASE_URL)
        response = requests.post(save_cc_url, data=data)
        return response.json()
