from rest_framework import generics, permissions, status, response, views
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from . import serializers
#from django.utils import simplejson
from djoser.openstack_api import get_vm_instances_of_user, get_vm_server_by_id, unpause_vm_server, pause_vm_server,get_all_images , get_all_flavors , create_vm, delete_vm_server, get_hypervisor_ip, get_port, add_ip_and_port
from rest_framework import permissions, status, response, views
# from .serializers import CreatevmSerializer
import uuid as hash_function
from .models import VirtualMachine, VirtualMachineFlavor
from django.views.generic import View

# User = get_user_model()


# Geting the vm of the requestd user
class MyRESTView(APIView):
    permission_classes = (
        permissions.IsAuthenticated,
    )

    def get(self, request, *args, **kw):
        vm_list = get_vm_instances_of_user(request.user.username, request.user.auth_token.key)
        return Response(
            data=vm_list,
            status=status.HTTP_200_OK,
        )


class CreateVirtualMachine(APIView):
    permission_classes = (
        permissions.IsAuthenticated,
    )

    def post(self, request):
        # <view logic>
	print("Entered the view")
	data = request.POST.dict()
        ram = int(data["ram"])
	disk = int(data["disk"])
	vcpus = int(data["vcpus"])
	# flavor = data["flavor"]
        flavor_code = "%02d%02d%03d" % (vcpus, ram, disk)
        flavor_model = VirtualMachineFlavor.objects.filter(flavor_code=flavor_code)[0]
        if not flavor_model:
            flavor_model = VirtualMachineFlavor.objects.create(flavor_code=flavor_code,
                                                                ram=ram,
                                                                hdd=disk,
                                                                vcpus=vcpus,
                                                                daily=0,
                                                                monthly=0
                                                            )

        nova_instance = create_vm(data['vm_name'],data['image'], vcpus, ram, disk, data['description'], data['availability_zone'],self.request.user.username, self.request.user.auth_token.key)

	print(nova_instance.id)
	import pdb; pdb.set_trace()
        virtual_machine = VirtualMachine.objects.create(user=self.request.user,
vm_name=data["vm_name"], image=data["image"], flavor=flavor_model, description=data["description"], availability_zone=data["availability_zone"], openstack_id=nova_instance.id, location="", billing_type="")
        return HttpResponse('result')


# class Create_Vm(generics.CreateAPIView, generics.ListAPIView):

#     serializer_class = CreatevmSerializer
#     permission_classes = (
#         permissions.IsAuthenticated,
#     )

#     def actual_create(self, request):
#         data = request.POST.dict()

#     def perform_create(self, serializer):
#         serializer.save(user=self.request.user)
#         print(self.request.user.auth_token.key)
#         vmdata = (serializer.data)
#         # Listing all the avalbull images
#         print(vmdata)
#         print("-------------------------")

#         new_vm = create_vm(
#             vmdata['vm_name'],
#             vmdata['image'],
#             # vmdata['flavor'],
#             vmdata['ram'],
#             vmdata['vcpus'],
#             vmdata['disk'],
#             vmdata['description'],
#             vmdata['availability_zone'],
#             self.request.user.username,
#             self.request.user.auth_token.key
#         )

#         print("vmstatus" + new_vm.status)


# Listing all the avalbull images
class ListImages(APIView):
    permission_classes = (
        permissions.IsAuthenticated,
    )

    def get(self, request, *args, **kw):
        imgs = get_all_images(request.user.username, request.user.auth_token.key)
        # data = simplejson.dumps(imgs)
        return Response(
            data=imgs,
            status=status.HTTP_200_OK,
        )


# Listing all the avalbull Flavers
class ListFlavors(APIView):
    permission_classes = (
        permissions.IsAuthenticated,
    )

    def get(self, request, *args, **kw):
        flav = get_all_flavors(request.user.username, request.user.auth_token.key)
        # data = simplejson.dumps(imgs)
        return Response(
           data=flav,
           status=status.HTTP_200_OK,
        )


# Start or Pause the vm based on the state of the vm
class StartVmsServer(APIView):
    permission_classes = (
        permissions.IsAuthenticated,
    )

    def get(self, request, *args, **kw):
        vm_server_id = request.GET.get('vms_id')
        vm_server = get_vm_server_by_id(vm_server_id,
                    request.user.username,
                    request.user.auth_token.key)
        response = unpause_vm_server(vm_server, request.user.username, request.user.auth_token.key)
        resp = {'status': 'success'}
        if response:

            resp['message'] = 'Server started successfully.'
        else:
            resp['message'] = 'Server is already in running state.'
        return Response(
                data=resp,
                status=status.HTTP_200_OK,
            )


class PauseVmsServer(APIView):
    permission_classes = (
        permissions.IsAuthenticated,
    )

    def get(self, request, *args, **kw):
        vm_server_id = request.GET.get('vms_id')
        print("pause vm:{0}".format(vm_server_id))
        vm_server = get_vm_server_by_id(
                        vm_server_id,
                        request.user.username,
                        request.user.auth_token.key
                        )
        VirtualMachine.objects.filter(openstack_id=vm_server_id)[0].pause()

        if vm_server:
            response = pause_vm_server(vm_server, request.user.username, request.user.auth_token.key)
            resp = {"status": "success"}
            if response:
                resp["message"] = "Server paused successfully."
            else:
                resp["message"] = "Server is already in paused state."

            return Response(
                    data=resp,
                    status=status.HTTP_200_OK,
            )
        else:
            resp["message"] = "Server not found"
            return Response(
                data=resp,
                status=status.HTTP_404_NOT_FOUND
            )


class DeleteVmsServer(APIView):
    permission_classes= (
        permissions.IsAuthenticated,
    )

    def get(self, request, *args, **kw):
        vm_server_id = request.GET.get('vms_id')
        vm_server = get_vm_server_by_id(vm_server_id,
                    request.user.username,
                    request.user.auth_token.key
                )
        VirtualMachine.objects.filter(openstack_id=vm_server_id)[0].delete()
        print ('***********delete the vm:',vm_server_id,'*************')
        print('old vm status: ',vm_server.status)
        response = delete_vm_server(vm_server, request.user.username, request.user.auth_token.key)
        print(response)
        resp = {'status': 'success'}
        if response:
            resp['message'] = 'Server deleted successfully.'
        else:
            resp['message'] = 'Error: Server cannot be deleted.'

        return Response(
            data=resp,
            status=status.HTTP_200_OK,
        )


class AccessVm(APIView):
    permission_classes = (
        permissions.IsAuthenticated,
    )

    def get(self, request, *args, **kw):
        # TODO get the port number and IP add
        # write these to the db and return a token. websockify uses token to look into the db
        print("inside access_vm:", request.POST.dict())
        vm_server_uuid = request.POST.get('uuid')
        print (vm_server_uuid)
        uuid = vm_server_uuid.split("=")[1]
        print (uuid)
        print (get_hypervisor_ip)
        hypervisor_ip = get_hypervisor_ip(uuid) # if not found, return False
        print("hypervisor:", hypervisor_ip)
        port = ''
        if hypervisor_ip:
            port = get_port(uuid, hypervisor_ip)
        # generate a ramdom uui for the ip port pairs
        print("got port:",port)
        token_hash = hash_function.uuid4().hex
        print(token_hash)
        print ("connect to :",hypervisor_ip,":",port, "token: ", token_hash)

        if port:
            #write uuid,ip,port to VNCConnection model
            # TODO: Add mysql connection and insert data into that database.
            # database = djoser.openstack_api.connect_db(username="vncuser", password="systemongrid", url="192.168.2.18", database="VNCConnection")
            # query = "INSERT INTO vnc_details VALUES ({0}, {1})".format(token_hash, ip, port)
            # djoser.openstack_api.run_query(db=database, query=query)
            print("**************ready to write to db **********")
            add_ip_and_port(token_hash, hypervisor_ip, port)
            # connection_detail = VNCConnection.objects.create(token=token_hash, port=port, ip=hypervisor_ip)
            resp = {'status': 'success','token':token_hash}
            print ("return resp",resp)
            return Response(
                data=resp,
                status=status.HTTP_200_OK,
            )
        else:
            # ip or port not found, but the user is authenticated
            resp = {'status': 'success','token':'ip/port not found'}
            return Response(
                data=resp,
                status=status.HTTP_200_OK,
            )
