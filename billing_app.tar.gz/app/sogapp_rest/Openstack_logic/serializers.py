# from rest_framework import serializers
# from rest_framework import generics, permissions, status, response, views
# from djoser.openstack_api import get_vm_instances_of_user, get_vm_server_by_id, unpause_vm_server, pause_vm_server,get_all_images , get_all_flavors , create_vm 
# from rest_framework import permissions, status, response, views
# from rest_framework.response import Response
# from .models import Createvm
# from djoser.models import User


# class CreatevmSerializer(serializers.ModelSerializer):
#     user = serializers.CharField(source='user.username', read_only=True)
#     class Meta:
#         model = Createvm
#         fields = ('id','user','vm_name', 'image','ram','vcpus','disk','description','availability_zone')
#         read_only_fields = ('id',)
#         # print ('availability_zone')
     
    
#     # def create(self , validated_data):
#     #     createvm = Createvm.objects.create(
	  
#     #         vm_name = validated_data['vm_name'],
#     #         image = validated_data['image'],
#     #         flavor = validated_data['flavor'],
#     #         description = validated_data ['description'],
#     #         availability_zone = validated_data['availability_zone'],

#     #         )
#     #     createvm.save()
#     #     return createvm

#     # def update(self, instance, validated_data):
#     #     for field, value in validated_data.items():
#     #         setattr(instance, field, value)
#     #     return instance
#     # print (name , image , flavor)    
