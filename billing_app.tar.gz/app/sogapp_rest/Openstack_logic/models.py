from django.db import models
from django.conf import settings
from django.utils import timezone
# from .managers import CustomerManager


class VirtualMachineFlavor(models.Model):
    flavor_code = models.CharField(null=False, max_length=250)
    ram = models.IntegerField()
    hdd = models.IntegerField()
    vcpus = models.IntegerField()
    daily = models.FloatField(null=False)
    monthly = models.FloatField(null=False)
    # C12 = models.FloatField(null=False)
    # C24 = models.FloatField(null=False)
    created_at = models.DateTimeField(default=timezone.now)
    updated_at = models.DateTimeField(auto_now=True)


# class Createvm(models.Model):

#     # VM status
#     STOPPED = 0
#     RUNNING = 1
#     PAUSED = 2
#     DELETED = 3
#     STATUS = (
#         (DELETED, 'Deleted'),
#         (RUNNING, 'Running'),
#         (PAUSED, 'Paused'),
#     )

#     # VM's physical location
#     NEW_JERSEY = 0
#     CALIFORNIA = 1
#     LOCATION = (
#         (NEW_JERSEY, 'NEW_JERSEY'),
#         (CALIFORNIA, 'CALIFORNIA')
#     )

#     DAILY = 0
#     MONTHLY = 1
#     COMMITMENT = 2
#     BILLING_TYPE = (
#         (DAILY, 'Daily'),
#         (MONTHLY, 'Monthly'),
#         (COMMITMENT, 'Commitment')
#     )

#     user = models.ForeignKey(settings.AUTH_USER_MODEL, related_name='virtual_machines')
#     vm_name = models.CharField(max_length=50)
#     image = models.CharField(max_length=50)
#     #vm_flavor = models.ForeignKey(VMDetails)
#     #flavor = models.CharField(max_length=100)
#     ram = models.CharField(max_length=50)
#     vcpus = models.CharField(max_length=50)
#     disk = models.CharField(max_length=50)
#     description = models.CharField(max_length=100)
#     availability_zone = models.CharField(max_length=100)
#     openstack_id = models.CharField(null=False, max_length=200)
#     #location = models.IntegerField(choices=LOCATION)
#     #billing_type = models.IntegerField(choices=BILLING_TYPE)
#     billing_expiry = models.DateTimeField(blank=True, null=True, default=None)
#     last_payment = models.DateTimeField(blank=True, null=True, default=None)
#     running_days = models.PositiveIntegerField(default=0)
#     created_at = models.DateTimeField(auto_now_add=True)
#     updated_at = models.DateTimeField(auto_now=True)

#     def __str__(self):
#         return self.vm_name



class VirtualMachine(models.Model):

    # VM status
    STOPPED = 0
    RUNNING = 1
    PAUSED = 2
    DELETED = 3
    STATUS = (
        (DELETED, 'Deleted'),
        (RUNNING, 'Running'),
        (PAUSED, 'Paused'),
    )

    # VM's physical location
    NEW_JERSEY = 0
    CALIFORNIA = 1
    LOCATION = (
        (NEW_JERSEY, 'NEW_JERSEY'),
        (CALIFORNIA, 'CALIFORNIA')
    )

    DAILY = 0
    MONTHLY = 1
    COMMITMENT = 2
    BILLING_TYPE = (
        (DAILY, 'Daily'),
        (MONTHLY, 'Monthly'),
        (COMMITMENT, 'Commitment')
    )
    user = models.ForeignKey(settings.AUTH_USER_MODEL, related_name="virtual_machines")
    vm_name = models.CharField(max_length=50)
    image = models.CharField(max_length=50)
    flavor = models.ForeignKey(VirtualMachineFlavor)
    description = models.CharField(max_length=100)
    availability_zone = models.CharField(max_length=100)
    openstack_id = models.CharField(null=False, max_length=200)
    location = models.IntegerField(choices=LOCATION)
    billing_type = models.IntegerField(choices=BILLING_TYPE)
    billing_expiry = models.DateTimeField(blank=True, null=True, default=None)
    last_payment = models.DateTimeField(blank=True, null=True, default=None)
    running_days = models.PositiveIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def pause(self):
        # Pause VM logic here.
        print("pause")
        VirtualMachineActivity.objects.create(self, VirtualMachine.PAUSED)

    def resume(self):
        # Pause VM logic here.
        print("resume")
        VirtualMachineActivity.objects.create(self, VirtualMachine.RUNNING)

    def delete(self):
        # Pause VM logic here.
        print("delete")
        VirtualMachineActivity.objects.create(self, VirtualMachine.DELETED)

    def __str__(self):
        return self.vm_name


class VirtualMachineActivity(models.Model):

    virtual_machine = models.ForeignKey(VirtualMachine)
    status = models.IntegerField(choices=VirtualMachine.STATUS)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return "VirtualMachine id:{0} {1} at {2}".format(self.virtual_machine.id, VirtualMachine.STATUS[self.status][1], self.created_at)
