from django.contrib.auth.models import AbstractBaseUser , UserManager
from django.core.validators import RegexValidator
from django.db import models
from django.utils import timezone
from datetime import datetime
from Openstack_logic.models import VirtualMachine, VirtualMachineFlavor


# class MyMgr(BaseUserManager):
#   def create_user():


class User(AbstractBaseUser):
    # objects = MyMgr()
    username = models.CharField(max_length=254, unique=True)
    email = models.EmailField(blank=True , unique=True)
    first_name = models.CharField(max_length=30, blank=True)
    middle_name = models.CharField(max_length=5, blank=True)
    last_name = models.CharField(max_length=30, blank=True)
    address = models.CharField(max_length=254, blank=True)
    date_of_birth = models.DateField()
    phone_regex = RegexValidator(regex=r'^\+?1?\d{9,15}$', message="Phone number must be entered in the format: '+999999999'. Up to 15 digits allowed.")
    phone_number = models.CharField(validators=[phone_regex], max_length=30, blank=True) # validators should be a list
    date_joined = models.DateTimeField(('date joined'), default=timezone.now)
    is_active = models.BooleanField(default=True)
    is_superuser = models.BooleanField(default=False)
    is_admin = models.BooleanField(default=False)
    is_staff = models.BooleanField(default=False)
    credits = models.PositiveIntegerField(default=0)
    USERNAME_FIELD = 'username'
    REQUIRED_FIELDS = ['first_name', 'last_name' ,'date_of_birth', 'phone_number','email']
    objects = UserManager()

    def default_account(self):
        return self.credit_cards.filter(is_default=True)[0]

    def amount_due(self):
        # TODO: Add billing expiry logic
        today = datetime.datetime.now()
        vms = self.vm_set.filter(deleted_status=False) #, billing_expiry__gt=today)
        amount = 0.00
        for virtual_machine in vms:
            # TODO: Add monthly charge logic
            monthly_charge = virtual_machine.flavor.monthly
            # TODO: Add daily charge logic
            daily_charge = virtual_machine.flavor.daily
            if virtual_machine.billing_type == VirtualMachine.MONTHLY:
                # Created this month.
                if virtual_machine.created_at.month == today.month:
                    start_day = virtual_machine.created_at.day
                    amount += (today.day - start_day) * daily_charge
                else:
                    amount += monthly_charge
            else:
                # Daily VM.
                # We care when the VM is stopped.
                # Same day at 12 noon.
                amount += virtual_machine.running_days * daily_charge
                virtual_machine.running_days = 0
                virtual_machine.save()
        return amount

    # Substracts any amount of credits available and makes the payment.
    def charge(self, amount):
        print "Inside charge"
        if self.credits:
            print "Inside if"
            if self.credits >= amount:
                self.credits = self.credits - amount
                # BillingHistory.save()
                self.save()
            else:
                rem_amount = amount - self.credits
                self.credits = 0.00
                self.default_account().make_payment(rem_amount)
            self.save()
        else:
            print "Inside else"
            self.default_account().make_payment(amount)
