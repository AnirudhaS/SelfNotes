
class NovaServerNotFound(Exception):
    def __init__(self, uuid):
        self.uuid = uuid

    def __str__(self):
        return repr("Nova Server with UUID:{0} not found.".format(self.uuid))
