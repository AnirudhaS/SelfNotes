from novaclient import client
from novaclient.exceptions import NotFound as FlavorNotFound
from cinderclient import client as cclient
from .cinder_helper import cinderAuth, cinderMain
import time
import libvirt
import xml.etree.ElementTree as ET
import MySQLdb


class NovaHelper:

    def login(self):
        version = 2  # settings.NOVA_VERSION
        nova = client.Client(version, self.username, self.password,
                            self.username, self.auth_url, connection_pool=True)
        return nova

    def __init__(self, username, password, auth_url):
        self.username = username
        self.password = password
        self.auth_url = auth_url
        self.nova = login()

    def get_all_flavors(self):
        flavors = [(x.name, x.id) for x in self.nova.flavors.list()]
        return flavors

    def get_vm_instances(self):
        servers = self.nova.servers.list()
        flavors = get_all_flavors()
        

