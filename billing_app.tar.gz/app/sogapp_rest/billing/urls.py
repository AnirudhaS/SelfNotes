from django.conf.urls import patterns, url, include

from billing import views

urlpatterns = patterns(
    '',
    url(r'^update_cc/$', views.UpdateCCPayment.as_view()),
)
