from django.shortcuts import render
from rest_framework import generics, permissions, status, response, views
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
import stripe
from billing.models import StripeCCPayment
import datetime
# Create your views here.


class UpdateCCPayment(APIView):
    permission_classes = (
        permissions.IsAuthenticated,
    )

    def post(self, request):
        # TODO: Check if customer has 5 credit cards and return appropriate response.
        token = request.POST["stripeToken"]
        customer = stripe.Customer.create(
            source=token,
            description="SOG Customer"
        )
        card = customer["sources"]["data"][0]
        number = "XXXXXXXXXXXX{0}".format(card.last4)
        expiry = datetime.date(day=1, month=card.exp_month, year=card.exp_year)
        name = card.name
        nickname = request.POST["nickname"]

        stripe_object = StripeCCPayment.objects.create(
            number=number,
            expiry_date=expiry,
            cardholder_name=name,
            cvc_number=self.request.POST["cvc"],
            user=self.request.user,
            nickname=nickname
        )

        return Response(status=status.HTTP_201_CREATED)
