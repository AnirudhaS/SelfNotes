from __future__ import unicode_literals
from djoser.models import User
from django.conf import settings
from django.utils import timezone
from django.db import models

# Create your models here.


class BillingHistory(models.Model):
    user = models.ForeignKey(User)
    amount = models.FloatField(null=False, default=0.0)
    description = models.TextField(null=False)
    status = models.BooleanField(null=False, default=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)


class StripeCCPayment(models.Model):
    # TODO: Model should have
    # 4 digits
    # expiry date
    # NAME
    # cvc
    # Belongs to User
    # Nickname
    # is_default
    number = models.CharField(null=False, max_length=16)
    expiry_date = models.DateField()
    cardholder_name = models.CharField(null=False, max_length=250)
    cvc_number = models.CharField(null=False, max_length=10)
    user = models.ForeignKey(User, related_name="credit_cards")
    nickname = models.CharField(max_length=150)
    is_default = models.BooleanField(default=False)
    # TODO: Added stripe_customer_id or stripe objec
