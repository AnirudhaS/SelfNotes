from celery import Celery
from SogProject.celery import app
from djoser.models import User
from Openstack_logic.models import VirtualMachine, VirtualMachineFlavor
from billing import BillingHistory


@app.task
def print_hello():
    print("Hello World")

@app.task
def update_vm_information():

    all_vms = VirtualMachine.objects.filter(status=VM.DELETED)
    this_month = datetime.datetime.now().month
    today = datetime.datetime.now()

    # Updated VM.deleted_status for the VM. Refer to the model for details.
    for virtual_machine in all_vms:
        if virtual_machine.updated_at.month is not this_month:
            virtual_machine.deleted_status = True
            virtual_machine.save()

    # Update VM.running_days
    all_vms = VirtualMachine.objects.filter(~Q(status=VM.DELETED))

    for virtual_machine in all_vms:
        if virtual_machine.status == VirtualMachine.RUNNING:
            virtual_machine.running_days += 1
        else:
            # Get activity log for yesterday. Filter them by day.
            # If paused today, then increment. Else don't.
            yesterday = datetime.datetime.now() - datetime.timedelta(days=1)
            virtual_machine.vmactivity_set.filter(create_at=yesterday)

            activity = virtual_machine.vmactivity_set.all().order_by('-created_at')[0]
            if activity.created_at.date() is today.date() and activity.status is VirtualMachine.PAUSED: virtual_machine.running_days += 1
        virtual_machine.save()


@app.task
def show_me_the_money():

    today = datetime.now()
    all_users = User.objects.all()
    # TODO: Add billing expiry to this.
    # TODO: Add description variable for every billing item.
    for user in all_users:
        vms = user.virtual_machines.filter(deleted_status=False, billing_expiry__gt=today)
        amount = 0.00
        for virtual_machine in vms:
            # TODO: Add monthly charge logic
            monthly_charge = virtual_machine.flavor.monthly
            # TODO: Add daily charge logic
            daily_charge = virtual_machine.flavor.daily
            if virtual_machine.billing_type == VirtualMachine.MONTHLY:
                # Created this month.
                if virtual_machine.created_at.month == today.month:
                    start_day = virtual_machine.created_at.day
                    amount += (today.day - start_day) * daily_charge
                else:
                    amount += monthly_charge
            else:
                # Daily VirtualMachine.
                # We care when the VirtualMachine is stopped.
                # Same day at 12 noon.
                # Reset running days to 0 here.
                amount += virtual_machine.running_days * daily_charge
                virtual_machine.running_days = 0
                virtual_machine.save()
            user.charge(amount)
