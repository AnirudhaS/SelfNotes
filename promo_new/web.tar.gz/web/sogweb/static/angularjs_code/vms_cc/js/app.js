var listVMS = angular.module('VMListApp', []);
