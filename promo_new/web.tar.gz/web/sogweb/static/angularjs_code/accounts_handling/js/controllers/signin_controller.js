signin_app.controller('signInCtrl', function($scope, $http) {
  $scope.username = '';
  $scope.password = '';
  $scope.errorMessages = '';

  $scope.login = function(){
    var xsrf = $.param({username: $scope.username, password: $scope.password});
    $http({
      method: 'post',
      url: '/accounts/signin',
      data: xsrf,
      headers: {'Content-Type': 'application/x-www-form-urlencoded'}
    }).then(function successCallback(response) {
      if(response['data']['status'] == 'success'){
        window.location.assign('/cc');
      }
      else{
        $scope.errorMessages = response['data']['non_field_errors']
      }
    });
  }

}).config(function($interpolateProvider) {
  $interpolateProvider.startSymbol('[[');
  $interpolateProvider.endSymbol(']]');
});
