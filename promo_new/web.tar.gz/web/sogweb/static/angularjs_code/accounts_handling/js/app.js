var signin_app = angular.module('signIn', []);
var signup_app = angular.module('signUp', ['ui.validate', 'ngSanitize', ]);
