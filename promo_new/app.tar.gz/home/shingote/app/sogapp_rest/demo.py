from promo.models import GoodsPromo
import json

####################
rule = """{
"primary_product":
[{"id": "*", "qty": "*"}],
"secondary_product":
[{"id": "*", "qty": "*", "price": 0.75 }]
}"""
promo = GoodsPromo.objects.create(rules=rule, promo_code="FLAT", expiry="2016-10-10 10:10")

bill = {
    "promo": "FLAT",
    "items": [
        {"id": 1, "price": 10},
        {"id": 1, "price": 7},
        {"id": 2, "price": 7}],
    "total": 17
}
# {"promo": "FLAT", "items": [{"price": 10, "id": 1}, {"price": 7, "id": 1}, {"price": 7, "id": 2}], "total": 17}

####################
r = """{
"primary_product":
[{"id": 1, "qty": 2}],
"secondary_product":
[{"id": 1, "qty": 1, "price": 0.75, "price_point": "lowest" }]
}"""

GoodsPromo.objects.create(rules=r, expiry="2016-10-10 10:10", promo_code="SINGLE")

bill = {
  "promo": "SINGLE",
  "items": [
    {"id": 1, "price": 10},
    {"id": 1, "price": 7}],
  "total": 17
}
# {"promo": "SINGLE", "items": [{"price": 10, "id": 1}, {"price": 7, "id": 1}], "total": 17}
  ####################
rule = """{
"primary_product":
[{"id": 1, "qty": "*"}],
"secondary_product":
[{"id": 1, "qty": "*", "price": 0.75, "price_point": null }]
}"""

pr = GoodsPromo.objects.create(rules=rule, promo_code="FLATSINGLE", expiry="2016-10-10 10:10")


bill = {
    "promo": "FLATSINGLE",
    "items": [
        {"id": 1, "price": 10},
        {"id": 1, "price": 7},
        {"id": 2, "price": 7}],
    "total": 17
}

# {"promo": "FLATSINGLE", "items": [{"price": 10, "id": 1}, {"price": 7, "id": 1}, {"price": 7, "id": 2}], "total": 17}
promo.apply_promo(bill)
