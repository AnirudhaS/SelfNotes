from django.shortcuts import render
from django.http import HttpResponse
from django.views.generic import View
from rest_framework.response import Response
from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.views import APIView
from models import GoodsPromo
import json

# Create your views here.
# @api_view(['GET', 'POST'])
class MyView(APIView):
  def get(self, request):
    return render(request, 'promo/bill.html')

  def post(self, request):
    bill = json.loads(request.POST.get("bill"))
    promo_code = bill['promo']
    promo = GoodsPromo.objects.filter(promo_code=promo_code)[0]
    promo.apply_promo(bill)
    return Response(
        data=bill,
        status=status.HTTP_200_OK,
      )


class CreateRule(APIView):
  def get(self, request):
    return render(request, 'promo/create_rule.html')

  def post(self, request):
    return render(request, ")")

