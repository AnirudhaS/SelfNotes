from django.conf.urls import patterns, url, include
from promo import views

urlpatterns = patterns(
    '',
    url(r'^$', views.MyView.as_view()),
)

