import json
from django.db import models
# from django.contrib.contenttypes.fields import GenericForeignKey
# from django.contrib.contenttypes.models import ContentType
# from django.contrib.contenttypes.fields import GenericRelation
# Create your models here.


class Rule(models.Model):
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    details = models.TextField()


class Promo(models.Model):
    expiry = models.DateTimeField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True


class GoodsPromo(Promo):
    rules = models.TextField()
    promo_code = models.CharField(null=False, max_length=25)

    def get_rules(self):
        return json.loads(self.rules)

    def apply_promo(self, bill):
        # rules = self.rule_set.all()
        # for rule in rules:
        # Add check for id = "*" and qty = "*" and only one primary product
        rule = json.loads(self.rules)

        primary_products = rule['primary_product']
        secondary_products = rule['secondary_product']

        for primary_product in primary_products:
            if not check_bill_for_product(bill, primary_product):
                return
        for secondary_product in secondary_products:
            apply_discount(bill, secondary_product)

#             if primary_product['id'] is "*":
#                 if primary_product['qty'] is "*":
#                     # Flat discount on everything.
#                     discount = secondary_products[0]['price']
#                     bill['total'] -= discount * bill['total']
#                     return
#                 else:
#                     if len(bill['items']) > primary_product['qty']:

# # if primary_product['qty'] is "*":
# #     if primary_product['id'] is "*":
# #         discount = secondary_products[0]['price']
# #         bill['total'] -= discount * bill['total']
# #         return
# #     # Check the bill for the product.
# #     if not check_bill_for_product(bill, primary_product):
# #         return
# # if not check_bill_for_product(bill, primary_product):
# #     return

#         # if secondary_products only 1, and id = "*", apply flat discount
#         for secondary_product in secondary_products:
#             # deduct appropriate amounts.
#             apply_discount(bill, secondary_product)


def apply_discount(bill, product):

    if product['id'] is "*":
        if product['qty'] is "*":
            discount = product['price']
            bill['total'] -= discount * bill['total']
            return
        else:
            if product['price_point'] == "highest":
                highest_item = bill['items'][0]
                for item in bill['items']:
                    if item['price'] > highest_item['price']:
                        highest_item = item
                # print "item gets discount."
                highest_item['price'] -= product['price'] * highest_item['price']

            elif product['price_point'] == "lowest":
                lowest_item = bill['items'][0]
                for item in bill['items']:
                    if item['price'] < lowest_item['price']:
                        lowest_item = item
                lowest_item['price'] -= product['price'] * lowest_item['price']
                # lowest_item['price'] = discount
            else:
                # if product.price_point is None
                quantity = product['qty']
                for item in bill['items']:
                    print "apply discount here."
                    item['price'] -= product['price'] * item['price']
                    quantity -= 1
    else:
        # product id is not "*"
        if product['qty'] is "*":
            for item in bill['items']:
                discount = product['price']
                if item['id'] is product['id']:
                    item['price'] -= discount * item['price']
        else:
            if product['price_point'] == "highest":
                highest_item = bill['items'][0]
                # Lookup the first item with product.id.
                for item in bill['items']:
                    if item['id'] is product['id']:
                        highest_item = item
                for item in bill['items']:
                    if item['price'] > highest_item['price'] and item['id'] is product['id']:
                        highest_item = item
                # print "item gets discount."
                highest_item['price'] -= product['price'] * highest_item['price']

            elif product['price_point'] == "lowest":
                lowest_item = bill['items'][0]
                # Lookup the first item with product.id.
                for item in bill['items']:
                    if item['id'] is product['id']:
                        lowest_item = item
                for item in bill['items']:
                    if item['price'] < lowest_item['price'] and product['id'] is item['id']:
                        lowest_item = item
                lowest_item['price'] -= product['price'] * lowest_item['price']
                # lowest_item['price'] = discount
            else:
                # if product.price_point is None
                quantity = product['qty']
                for item in bill['items']:
                    if item['id'] is product['id'] and quantity:
                        print "apply discount here."
                        item['price'] -= product['price'] * item['price']
                        quantity -= 1

    # if product['price_point'] == "highest":
    #     highest_item = bill['items'][0]
    #     for item in bill['items']:
    #         if item['price'] > highest_item['price']:
    #             highest_item = item
    #     # print "item gets discount."
    #     highest_item['price'] -= product['price'] * highest_item['price']

    # elif product['price_point'] == "lowest":
    #     lowest_item = bill['items'][0]
    #     for item in bill['items']:
    #         if item['price'] < lowest_item['price']:
    #             lowest_item = item
    #     lowest_item['price'] -= product['price'] * lowest_item['price']
    #     # lowest_item['price'] = discount
    # else:
    #     # if product.price_point is None
    #     quantity = product['qty']
    #     for item in bill['items']:
    #         if item['id'] is product['id'] and quantity:
    #             print "apply discount here."
    #             item['price'] -= product['price'] * item['price']
    #             quantity -= 1


def check_bill_for_product(bill, product):
    # if quantity is "*" only check the product.id
    quantity = product['qty']
    for item in bill['items']:
        if product['id'] is "*":
            if quantity is "*":
                return True
            quantity -= 1
        else:
            if item['id'] is product['id']:
                if quantity is "*":
                    return True
                quantity -= 1

        # if item['id'] is product['id']:
        #     if quantity is "*":
        #         return True
        #     quantity -= 1

    if (quantity > 0):
        return False
    else:
        return True
