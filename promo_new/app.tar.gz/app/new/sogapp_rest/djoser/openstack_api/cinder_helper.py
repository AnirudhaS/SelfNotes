from cinderclient import client as cclient
from .keystone_helper import get_keystone_instance
# import MySQLdb
import time

#method to execute mysql query on database cluster
def doQuery(query):
	print "here now"
	host = "192.168.2.23"
	user = "cinder"
	passwd = "systemongrid"
	database = "cinder"
	db = MySQLdb.connect(host, user, passwd, database)
	cur = db.cursor()
	cur.execute(query)
	db.commit()	
	db.close()
#cinder authentication, returns cinder object 
def cinderAuth():
	username = "admin"
	version = '2'
	passwd = "systemongrid"
	auth_url = "http://vsusnjhhdiosconvip:5000/v2.0"
	tenant_name = "admin"
	cinder = cclient.Client(version, username, passwd, tenant_name, auth_url)

	return cinder

#checkStatus of volume
def checkStatus(vol_id):
	ready = False
	cinder = cinderAuth()
	vol = cinder.volumes.get(vol_id)
	status = vol.status
	while status != 'available':
		print "Before time.sleep"
		time.sleep(5)
		print "After time.sleep"
		vol = cinder.volumes.get(vol.id)
		status = vol.status
		print vol.name + " " + status
		if status == 'available': 
			ready = True
			break
	return ready
#execute new volume method
def newVol(cinder_obj, size, name, description, avail_zone, vol_source_id):
	cinder = cinderAuth()
	new_vol = cinder.volumes.create(size=size, name=name, description=description, availability_zone=avail_zone, source_volid=vol_source_id)
	return new_vol
#transfer volume 
def transferVol(vol_id, username):
	status = checkStatus(vol_id)
	if status == True:
		ks = get_keystone_instance()
		for user in ks.users.list():
			if user.name == username:
				user_id = user.id
				proj_id = user.tenantId
		print user_id
		print proj_id
		print vol_id
		query = "UPDATE volumes SET user_id = '%s', project_id = '%s' WHERE id = '%s'" % (user_id, proj_id, vol_id)
		doQuery(query)
		print "Volume transfered successfully"
		return True
	else:
		return False
def cinderMain(cinder, size, name, description, availability_zone, vol_source_id):
	transferVol(newVol(cinder, size, name, description, avail_zone, vol_source_id).id, username)

if __name__ == "__main__":
    transferVol(newVol(cinderAuth(), '20', 'khalil_vol16', 'testing cinder script', 'nova', 'f8925328-b15a-4dc4-830c-3ca0fd353742').id, 'khalilyasim')

	
