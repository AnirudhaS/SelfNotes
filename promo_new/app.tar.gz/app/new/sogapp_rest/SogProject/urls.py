from django.conf.urls import patterns, url, include
from promo import views as promo_views
urlpatterns = patterns('',
    url(r'^auth/', include('djoser.urls.authtoken')),
    url(r'^docs/', include('rest_framework_swagger.urls')),
    url(r'^promo/', include('promo.urls')),
    url(r'^vms/', include('Openstack_logic.urls')),
)
