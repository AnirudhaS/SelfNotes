# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import django.utils.timezone
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name='Createvm',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('vm_name', models.CharField(max_length=50)),
                ('image', models.CharField(max_length=50)),
                ('description', models.CharField(max_length=100)),
                ('availability_zone', models.CharField(max_length=100)),
                ('openstack_id', models.CharField(max_length=200)),
                ('location', models.IntegerField(choices=[(0, b'NEW_JERSEY'), (1, b'CALIFORNIA')])),
                ('billing_type', models.IntegerField(choices=[(0, b'Daily'), (1, b'Monthly'), (2, b'Commitment')])),
                ('billing_expiry', models.DateTimeField(default=None, null=True, blank=True)),
                ('last_payment', models.DateTimeField(default=None, null=True, blank=True)),
                ('running_days', models.PositiveIntegerField(default=0)),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
                ('user', models.ForeignKey(related_name='virtual_machines', to=settings.AUTH_USER_MODEL)),
            ],
        ),
        migrations.CreateModel(
            name='VMDetails',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('vm_flavor', models.CharField(max_length=250)),
                ('daily', models.FloatField()),
                ('monthly', models.FloatField()),
                ('C12', models.FloatField()),
                ('C24', models.FloatField()),
                ('created_at', models.DateTimeField(default=django.utils.timezone.now)),
                ('updated_at', models.DateTimeField(auto_now=True)),
            ],
        ),
        migrations.AddField(
            model_name='createvm',
            name='vm_flavor',
            field=models.ForeignKey(to='Openstack_logic.VMDetails'),
        ),
    ]
