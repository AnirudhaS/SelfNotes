from keystoneclient.v2_0 import client
from novaclient import client
from djoser.openstack_api import *

class CalcClass(object):

    def __init__(self, *args, **kw):
        # Initialize any variables you need from the input you get
        pass

    def do_work(self):
    	VERSION = 2
       	USERNAME = "restframework4"
        print ("Calling beffore passwod")
       	PASSWORD = "msreddy"
       	PROJECT_NAME = "restframework4"
       	AUTH_URL = "http://vsusnjhhdiosconvip:5000/v2.0"

       	nova = client.Client(VERSION , USERNAME, PASSWORD, PROJECT_NAME ,AUTH_URL, connection_pool=True)

     #  #Command to list out images 
      #	print ("Calling before images")
       	imgs = [(x.name , x.id) for x in nova.images.list()]

     #  #Command to list out flavers

     #	fla = [(x.name , x.id) for x in nova.flavers.list()]
        # Do some calculations here
        # returns a tuple ((1,2,3, ), (4,5,6,))
     #   result = ((1,2,3, ), (4,5,6,)) # final result
        result = (imgs)
        return result
