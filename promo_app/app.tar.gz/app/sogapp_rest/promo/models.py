from django.db import models

# Create your models here.

class Rule(models.Model):
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    details = models.TextField()

    promo_type = models.ForeignKey(ContentType, on_delete=models.CASCADE)
    promo_id = models.PositiveIntegerField()
    promo = GenericForeignKey('promo_type', 'promo_id')


class Promo(models.Model):
    expiry = models.DateTimeField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True


class GoodsPromo(Promo):
    
    def apply_promo(self, bill):
        rules = self.rule_set.all()
        for rule in rules:
            # Add check for id = "*" and qty = "*" and only one primary product
            primary_products = rule.primary_product
            for primary_product in primary_products:
                return if not check_bill(bill, primary_product)

            secondary_products = rule.secondary_products
            for secondary_product in secondary_products:
                # deduct appropriate amounts.
                apply_discount(bill, product)


def apply_discount(bill, product):
    # if id = "*", apply flat discount
    if product.price_point == "highest":
        highest_item = bill[0]
        for item in bill:
            if item.product_price > price:
                highest_item = item
        print "item gets discount."
    else if product.price_point == "lowest":
        lowest_item = bill[0]
        for item in bill:
            if item.product_price < price:
                lowest_item = item
        print "item gets discount."
    else:
        # if product.price_point is None
        quantity = product.quantity
        for item in bill:
            if item.id is product.id and quantity:
                print "apply discount here."
                quantity -= 1
        



def check_bill_for_product(bill, product):
    # if quantity is "*" only check the product.id
    quantity = product.quantity
    for item in bill:
        if item.id is product.id:
            quantity -= 1

    return False if (quantity > 0) else return True
