"""
Helper module to make request to app server
"""

import requests

from django.conf import settings


class VirtualMachine(object):
    """
    Helper class to get ,update or create  vms app related
    data on sogapp server.
    """

    @classmethod
    def get_user_vms(cls, auth_token):
        """
        This method gets virtual machines of logged in user.
        """

        vmlist_url = '{}vms/'.format(settings.APP_SERVER_BASE_URL)
        payload = {'auth_token': auth_token}
        headers = {
            'Authorization': "Token %s" % (auth_token)
        }

        resp = requests.get(vmlist_url, data=payload, headers=headers)
        response = resp.json()
        return response

    @classmethod
    def start_vms(cls, auth_token, vms_name):
        """
        This method starts given vms server.
        """

        start_vms_url = '{}vms/start_vms/'.format(settings.APP_SERVER_BASE_URL)
        payload = {'vms_name': vms_name}
        headers = {
            'Authorization': "Token %s" % (auth_token)
        }

        resp = requests.get(start_vms_url, params=payload, headers=headers)
        response = resp.json()
        return response

    @classmethod
    def pause_vms(cls, auth_token, vms_name):
        """
        This method pause given vms server.
        """

        pause_vms_url = '{}vms/pause_vms/'.format(settings.APP_SERVER_BASE_URL)
        payload = {'vms_name': vms_name}
        headers = {
            'Authorization': "Token %s" % (auth_token)
        }

        resp = requests.get(pause_vms_url, params=payload, headers=headers)
        response = resp.json()
        return response

    @classmethod
    def delete_vms(cls, auth_token, vms_name):
        """
        This method pause given vms server.
        """

        pause_vms_url = '{}vms/delete_vms/'.format(settings.APP_SERVER_BASE_URL)
        payload = {'vms_name': vms_name}
        headers = {
            'Authorization': "Token %s" % (auth_token)
        }

        resp = requests.get(pause_vms_url, params=payload, headers=headers)
        response = resp.json()
        return response
