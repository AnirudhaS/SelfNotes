"""
Module contains decorator functions
"""

from django.http import HttpResponseRedirect
from django.core.urlresolvers import reverse
from django.contrib import messages

def valid_token_only(action):
    """
    Checks whether auth token is presenet or not in session.
    If not present redirected to sign in page. Almost analogous to
    login_required.
    """

    def inner_func(*args, **kwargs):
        """
        checks if auth token is present in session
        """
        request = args[0]
        if 'auth_token' not in request.session:
            messages.error(request, 'You need to signin first')
            return HttpResponseRedirect(reverse('accounts:signin'))
        return action(*args, **kwargs)
    return inner_func

def credit_card_required(action):
    """
    Checks whether user has credit cards.
    If not then redirected to the index page.
    """

    def inner_func(*args, **kwargs):
        """
        Checks if user has credit cards.
        """

        request = args[0]
        if not request.session.get('credit_card_present'):
            messages.error(request, 'You need to enter credit card details first')
            return HttpResponseRedirect(reverse('vms:vm_index'))
        return action(*args, **kwargs)
    return inner_func

def anonymous_only(action):
    """
    Checks whether user is anomympos
    If not then redirected to the home page.
    """

    def inner_func(*args, **kwargs):
        """
        Checks if auth token is present in session or not.
        """

        request = args[0]
        if 'auth_token' in request.session:
            if request.session['auth_token']:
                return HttpResponseRedirect(reverse('main_home'))
        return action(*args, **kwargs)
    return inner_func

